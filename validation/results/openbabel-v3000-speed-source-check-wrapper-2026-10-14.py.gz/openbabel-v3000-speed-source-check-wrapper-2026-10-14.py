import hashlib,json,subprocess,sys
from pathlib import Path
root=Path.cwd(); temp=Path('/private/tmp/chematic-openbabel-v3000-20261014'); source_path=root/'benchmarks/2026-10-14-openbabel-v3000-speed-source.json'; source=json.loads(source_path.read_bytes()); sha=lambda b:hashlib.sha256(b).hexdigest(); frozen=Path('/private/tmp/chematic-openbabel-speed-source-20261014')
def check_frozen():
 for path,h in source['frozen_build_source_sha256'].items(): assert sha((frozen/path).read_bytes())==h,path
check_frozen()
for profile,count in [('0',1000),('5000',1000),('chains',64)]:
 output=root/'benchmarks'/f'2026-10-14-openbabel-v3000-speed-{profile}-paired21.json'
 command=[sys.executable,'scripts/bench_openbabel_v3000_throughput.py','--baseline',str(temp/'baseline-v3000'),'--candidate',str(temp/'candidate-v3000'),'--openbabel',str(temp/'openbabel-v3000'),'--corpus',str(temp/f'corpus-{profile}.molblocks'),'--output',str(output),'--source-manifest',str(source_path),'--records',str(count),'--blocks','21','--repeats','5']
 with (temp/f'paired21-{profile}.log').open('w') as log: result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 try: assert result.returncode==0,result.returncode; check_frozen()
 except Exception:
  if output.exists():
   d=json.loads(output.read_bytes()); d['complete']=False; d['frozen_build_integrity_passed']=False; output.write_text(json.dumps(d,indent=2)+'\n')
  raise
 d=json.loads(output.read_bytes()); d['frozen_build_integrity_passed']=True; output.write_text(json.dumps(d,indent=2)+'\n')
 print('Completed profile',profile,flush=True)
