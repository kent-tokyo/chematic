import hashlib,json,subprocess,sys
from pathlib import Path
root=Path.cwd(); temp=Path('/private/tmp/chematic-speed-stage3-20261014'); source_path=root/'benchmarks/2026-10-14-python-first-use-followup-source.json'; source_bytes=source_path.read_bytes(); source=json.loads(source_bytes); frozen=Path('/private/tmp/chematic-speed-stage3-source-20261014'); sha=lambda b:hashlib.sha256(b).hexdigest()
def check():
 assert source_path.read_bytes()==source_bytes
 for field,base in [('changed_source_sha256',root),('benchmark_source_sha256',root),('build_source_sha256',frozen)]:
  for p,h in source[field].items(): assert sha((base/p).read_bytes())==h,(field,p)
 for arm,row in source['wheels'].items(): assert sha(Path(row['path']).read_bytes())==row['sha256'],arm
 for name,row in source['comparators'].items():
  for p,h in row['native_files_sha256'].items(): assert sha((Path(row['module_path'])/p).read_bytes())==h,(name,p)
check()
for offset in (0,5000):
 output=root/'benchmarks'/f'2026-10-14-python-first-use-followup-slice{offset}-paired20.json'
 command=[sys.executable,'scripts/bench_python_speed_frontier.py','--corpus','validation/benchmark_corpora/rdkit-js-browser-10k-v1.smi','--offset',str(offset),'--limit','1000','--blocks','20','--baseline-wheel',source['wheels']['baseline']['path'],'--baseline-path','/private/tmp/chematic-speed-stage2-20261014/arm-candidate','--candidate-wheel',source['wheels']['candidate']['path'],'--candidate-path',str(temp/'arm-final'),'--source-manifest',str(source_path),'--base-revision',source['base_revision'],'--output',str(output)]
 with (temp/f'paired20-slice{offset}.log').open('w') as log: result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 try: check(); assert result.returncode==0,result.returncode
 except Exception:
  if output.exists():
   d=json.loads(output.read_bytes()); d['complete']=False; d['source_integrity_passed']=False; output.write_text(json.dumps(d,indent=2)+'\n')
  raise
 d=json.loads(output.read_bytes()); assert d['complete']; d['source_integrity_passed']=True; d['source_manifest_sha256']=sha(source_bytes); output.write_text(json.dumps(d,indent=2)+'\n')
 print('Completed fixed slice',offset,flush=True)
