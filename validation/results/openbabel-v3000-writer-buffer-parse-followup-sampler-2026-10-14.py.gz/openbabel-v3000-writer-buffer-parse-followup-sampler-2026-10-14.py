import sys,os,json,hashlib,platform,subprocess
from pathlib import Path
from datetime import datetime,timezone
root=Path('/private/tmp/chematic-openbabel-writer-source-20261014');out=Path('/private/tmp/chematic-openbabel-writer-20261014');old=Path('/private/tmp/chematic-openbabel-v3000-20261014')
sys.path.insert(0,str(root/'scripts'))
from bench_openbabel_sdf_throughput import timing_row,paired_median_ratio_ci,sha
source=root/'benchmarks/2026-10-14-openbabel-v3000-writer-buffer-source.json';source_bytes=source.read_bytes();m=json.loads(source_bytes)
binaries={arm:out/f'{arm}-v3000' for arm in ['baseline','candidate']}
report={'schema':'openbabel-v3000-parser-focused-followup/v1','created_utc':datetime.now(timezone.utc).isoformat(),'source_manifest_sha256':sha(source_bytes),'binaries':{a:{'path':str(p),'sha256':sha(p.read_bytes())} for a,p in binaries.items()},'host':{'platform':platform.platform(),'cpus':os.cpu_count()},'protocol':{'adaptive_trigger':'CI-below-1 baseline parse ratios in the two complete diverse-profile matrices','blocks':21,'repeats':5,'order':'two source arms rotate sequential fresh processes; Open Babel arm omitted only in this separate incremental followup','timing':'unchanged native harness including prepared warm write before parse','pooling':'none; original three-arm matrices and every repeat sample retained'},'profiles':{},'complete':False}
for profile in ['0','5000']:
 corpus=old/f'corpus-{profile}.molblocks';assert sha(corpus.read_bytes())==m['corpora'][profile]['output_sha256']
 original=json.loads((root/f'benchmarks/2026-10-14-openbabel-v3000-writer-buffer-{profile}-paired21.json').read_text());assert original['complete'] and original['source_parse_snapshots_equal']
 blocks=[]
 for block in range(21):
  order=['baseline','candidate'] if block%2==0 else ['candidate','baseline'];row={'order':order,'load_average_start':list(os.getloadavg())}
  for arm in order:row[arm]=timing_row(binaries[arm],corpus,'parse',5,1000)
  blocks.append(row)
 interval=paired_median_ratio_ci([b['baseline']['elapsed_ns'] for b in blocks],[b['candidate']['elapsed_ns'] for b in blocks],seed=0)
 report['profiles'][profile]={'corpus':{'sha256':sha(corpus.read_bytes()),'records':1000},'blocks':blocks,'baseline_over_candidate':interval}
 print(profile,interval,flush=True)
for a,p in binaries.items():assert sha(p.read_bytes())==report['binaries'][a]['sha256']
assert source.read_bytes()==source_bytes
report['complete']=True
(root/'benchmarks/2026-10-14-openbabel-v3000-writer-buffer-parse-repeat21.json').write_text(json.dumps(report,indent=2)+'\n')
