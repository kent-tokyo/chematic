# Contributing to chematic

Thank you for your interest in contributing! chematic is a pure-Rust cheminformatics library — contributions of all sizes are welcome.

## Quick start

```bash
git clone https://github.com/kent-tokyo/chematic.git
cd chematic
cargo test --workspace --lib --quiet   # 211 tests, all should pass
cargo clippy --workspace -- -D warnings
```

No C compiler, no Python, no external tools required for the core crates.

## Product names

Use the official lowercase names `chematic` and `chematic-draw`. An extra
leading `s` is a typo. Run `python3 scripts/check_product_names.py` before
submitting documentation or package-metadata changes; CI enforces the same
rule. See [`docs/product-naming.md`](docs/product-naming.md) for the scope and
compatibility exclusions.

## Documentation build

The documentation site uses a pinned MkDocs environment so local verification
matches the Pages workflow. With `uv` installed:

```bash
UV_CACHE_DIR=/tmp/chematic-uv-cache uv venv .venv-docs
UV_CACHE_DIR=/tmp/chematic-uv-cache uv pip install --python .venv-docs/bin/python -r requirements-docs.txt
.venv-docs/bin/mkdocs build --strict --site-dir /tmp/chematic-mkdocs-site
```

The generated site and `.venv-docs` are local artifacts. `--strict` is required
for changes to the documentation site or its links.

## Stable extension points and validation corpus

Ecosystem integrations should implement `chematic_core::MoleculeExtension` and
register operations through `ExtensionRegistry`. Use a namespaced, versioned
ID such as `vendor.operation.v1`; do not overload an existing ID or change the
meaning of a published result without incrementing its contract version. The
interface is read-only and returns only scalar, vector, or text values so it
can be adapted consistently by native, WASM, and binding consumers.

Before adding a fixture or corpus, follow the repository policy in
[`docs/contributor-corpus-policy.md`](docs/contributor-corpus-policy.md).
Fixtures without provenance, redistribution terms, minimization notes, and a
pinned oracle version are not eligible for checked-in validation.

## Where to contribute

| Area | Crate | Difficulty |
|------|-------|-----------|
| Bug fixes anywhere | any | Easy |
| New molecular descriptors | `chematic-chem` | Easy — add a `pub fn` + tests |
| SMARTS pattern fixes | `chematic-smarts` | Medium |
| New file formats | `chematic-mol` | Medium |
| Force field parameters | `chematic-ff` | Medium–Hard |
| Kekulization / aromaticity | `chematic-core` | Hard |

**Easiest entry point**: `chematic-core` has zero external dependencies (no `[dependencies]` in `Cargo.toml`) and is pure safe Rust. Adding a helper to `molecule.rs` or a new descriptor to `chematic-chem/src/descriptors.rs` is a great first contribution.

## Branch naming

`feat/*` new feature · `fix/*` bug fix · `docs/*` docs only · `release/*` version bump + CHANGELOG + tag

## Release checklist

- Full-workspace doc build sanity check: `cargo doc --workspace --all-features --no-deps --exclude chematic-py`. Plain `cargo doc --workspace --all-features --no-deps` fails — `chematic-py`'s compiled lib is also named `chematic` (needed so it imports as `import chematic` from Python), which collides with the `chematic` facade crate's own rustdoc output path.

## Main branch protection (recommended settings)

GitHub → Settings → Branches → Add rule for `main`:

- [x] Require a pull request before merging
- [x] Require status checks: `Test`, `Clippy`, `Format Check`, `Build Check`
- [x] Do not allow bypassing the above settings

## Development workflow

```bash
# Run tests for a single crate
cargo test -p chematic-chem --lib --quiet

# Run a specific test by name
cargo test -p chematic-chem --lib -- hba_count

# Check native InChI feature (requires C compiler)
cargo test -p chematic-inchi --features native-inchi --lib --quiet
```

## Code coverage

The [Coverage workflow](https://github.com/kent-tokyo/chematic/actions/workflows/coverage.yml)
measures Rust library and binary unit tests with `cargo-llvm-cov` and uploads
LCOV to [Codecov](https://app.codecov.io/github/kent-tokyo/chematic). It also saves
LCOV and an HTML report as the `rust-unit-coverage` Actions artifact.

The scope uses default features plus `chematic-inchi/native-inchi`, and excludes
`chematic-py`, `chematic-wasm`, the offline `gen-sa-table` tool, and a manual
ignored differential-evaluation harness. It includes the named Rust integration
contracts in the command below; other integration tests, Python/WASM runtime
tests, doctests, and optional-feature lanes are not part of this percentage.
Coverage describes executed code; chemistry correctness and cross-engine
compatibility still depend on their separate validation gates.

To reproduce locally:

```bash
rustup component add llvm-tools-preview
cargo install cargo-llvm-cov --version 0.8.7 --locked
mkdir -p target/coverage
cargo llvm-cov --locked --workspace --lib --bins \
  --features chematic-inchi/native-inchi \
  --test qcschema --test nucleic_acid_contract --test v3000_semantic_interop \
  --test rdkit_embed --test streamable_http \
  --test format_binding_parity --test conformer_3d_io --test schema_conformance \
  --test rdkit_g1_parity --test issue739_platform_stereo \
  --test rdkit_count_and_chiral_fps --test rdkit_morgan_stable_api_fixtures \
  --test rdkit_2026_09_1_ring_count --test issue769_template_valence \
  --test rdkit_inchi_read --test rdkit_canonical_smiles \
  --test stereo2d_ez_reader_integration --test stereo_reader_integration \
  --test mmff94_rdkit_per_term_energy --test mmff94_rdkit_residuals_734 \
  --test prepared_cache --test lowercase_symbol_primitives \
  --test rdkit_tpsa_sign --test rdkit_canonical_ranks_ez \
  --test atom_order --test pseudoatom_roundtrip \
  --test canonical_smiles_reaction_product_order --test cross_binding_contract \
  --test issue455_explicit_h_valence --test issue769_neutral_valence \
  --test cip_lone_pair_ring_centre_rdkit_reading \
  --test cross_binding_adversarial --test mmcif_pqr_integration \
  --test square_planar_mol_io --test atom_tag_cache --test atom_tag_visit_order \
  --test dative_bond_direction --test square_planar_stereo \
  --test explicit_h_stereo --test ez_stash_stereo0d \
  --test indexed_graph_relation --test invert_stereocenter_p0_stereo_invariance \
  --test accurate_cip_preflight --test dedup_fixtures --test standard_inchi \
  --test descriptor_contract --test rdkit_reference --test metal_disconnect_holdout \
  --test standardize_stereo_table_preservation --test aromaticity_edge_gate \
  --test issue415_fused_heteroaromatic_holdout \
  --test mmff94_rdkit_bfgs_trajectory \
  --test g1_regression_byte_identical --test torsion_knowledge_negative_controls \
  --test canonical_stereo_d0_cip_multiset_invariance \
  --test neighbor --test periodicity \
  --test canonical_ez_planner_order --test canonical_ez_residual \
  --test canonical_robustness \
  --test chembl_roundtrip --test canonical_idempotency_corpus \
  --test canonical_idempotency_corpus_standardized \
  --exclude chematic-py --exclude chematic-wasm --exclude gen-sa-table \
  --no-report
cargo llvm-cov report \
  --ignore-filename-regex '(crates/(chematic-py|chematic-wasm)/|tools/gen_sa_table/|crates/chematic-3d/src/issue256_255_phase2_evaluation.rs)' \
  --lcov --output-path target/coverage/lcov.info
cargo llvm-cov report \
  --ignore-filename-regex '(crates/(chematic-py|chematic-wasm)/|tools/gen_sa_table/|crates/chematic-3d/src/issue256_255_phase2_evaluation.rs)' \
  --html --output-dir target/coverage
```

Uploads use GitHub Actions OIDC (`id-token: write`), so no `CODECOV_TOKEN`
secret is required. Public coverage results can be viewed without signing in;
account and repository settings require a separate Codecov login.
Fork pull requests use the Codecov action's
public-repository tokenless upload path. Upload errors fail the Coverage job;
the saved artifact helps distinguish measurement from upload problems.
Dependabot pull requests still produce reports, but skip the Codecov upload
because their read-only workflow permissions cannot request an OIDC token.

Project and patch coverage checks are initially informational in `codecov.yml`.
They show changes without imposing a minimum percentage before a baseline is
available. The existing test and compatibility checks remain required.

## Code style

- **No unsafe code** — `#![forbid(unsafe_code)]` is enforced in all crates, except the `native-inchi` feature's C FFI boundary (`crates/chematic-inchi/src/native/`).
- **No external C/C++ deps** by default (the `native-inchi` feature is the only exception).
- **WASM-compatible** — core crates must not use `std::fs`, threads, or OS-specific APIs.
- **Justify unsafe/unwrap/expect/panic!** outside `#[cfg(test)]` with a `// safe: ...` comment explaining why it cannot fail (e.g. `// safe: index bounds-checked above`).
- Format: `cargo fmt --workspace` before committing.
- Lints: `cargo clippy --workspace -- -D warnings` must pass (zero warnings).

## Adding a new descriptor

1. Add a `pub fn my_descriptor(mol: &Molecule) -> f64` in `crates/chematic-chem/src/descriptors.rs`
2. Export it in `crates/chematic-chem/src/lib.rs`
3. Add at least one `#[test]` with a known value (e.g. benzene, aspirin)
4. If it belongs in the Python API, add it to `Mol` in `crates/chematic-py/src/lib.rs`

## Pull requests

- Keep PRs focused — one feature or fix per PR.
- Include tests. New functions without tests will be asked to add them.
- Update `CHANGELOG.md` under `## [Unreleased]` with a brief description.
- CI must pass (`cargo test --workspace --lib --quiet` + `cargo clippy --workspace -- -D warnings`).

## Reporting issues

Use the [Bug report](.github/ISSUE_TEMPLATE/bug_report.md) template. A minimal SMILES reproduction is the most helpful thing you can provide.

## Questions

Open a [Discussion](https://github.com/kent-tokyo/chematic/discussions) — no need to file an issue for questions.
