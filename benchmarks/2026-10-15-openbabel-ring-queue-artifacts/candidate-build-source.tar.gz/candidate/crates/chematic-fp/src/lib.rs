//! `chematic-fp` — molecular fingerprints for chematic.
//!
//! Provides:
//! - **ECFP** (Extended Connectivity Fingerprints): Morgan-algorithm-based circular
//!   fingerprints using FNV-1a hashing for reproducibility.
//! - **MACCS 166-bit structural keys**: SMARTS-based structural key fingerprints.
//! - **Topological path fingerprints**: DFS path enumeration up to a configurable length.
//! - **AtomPair fingerprints**: atom-pair encoding with topological distances.
//! - **Topological Torsion fingerprints**: four-atom path encoding.
//! - **C-Series Reaction fingerprints**: Chemical transformation encoding (Phase 1)
//! - **MHFP/SECFP**: MinHash fingerprints for fast approximate similarity searching (Phase 1)
//! - **ERG**: Extended Reduced Graph fingerprints for functional group-based similarity (Phase 1)
//! - **FPS**: streaming read/write for the chemfp/OpenBabel FPS fingerprint interchange format
//!   ([`fps`])

#![forbid(unsafe_code)]
#[cfg(test)]
mod ecfp_config_boundary_contract_tests;
#[cfg(test)]
mod sparse_boundary_contract_tests;

pub mod atom_pair;
pub mod avalon;
pub mod bitvec;
pub mod bulk;
pub mod ecfp;
mod ecfp_diagnostics;
pub mod erg;
pub mod fcfp;
pub mod fps;
pub mod hdf;
pub mod layered;
pub mod lsh;
pub mod maccs;
pub mod map4;
pub mod mhfp;
mod morgan_environment;
pub mod path;
pub mod pattern;
pub mod pharmacophore_fp;
pub mod rdkit_atom_pair;
pub mod rdkit_avalon;
mod rdkit_isotope_delta_table;
pub mod rdkit_layered;
mod rdkit_morgan_config;
mod rdkit_morgan_ecfp4;
mod rdkit_morgan_hash;
pub mod rdkit_pattern;
pub mod rdkit_rdk;
pub mod rdkit_torsion;
pub mod reaction_fp;
pub mod search;
pub mod topo_path;

pub use atom_pair::{atom_pair_fp, torsion_fp};
pub use avalon::{AvalonConfig, avalon_fp, avalon_fp_with_config, tanimoto_avalon};
pub use bitvec::{BitVec2048, BitVecN};
pub use bulk::{tanimoto_matrix, tanimoto_matrix_parallel, tanimoto_slice, top_k_similar};
pub use ecfp::{
    EcfpConfig, EcfpInvariantMode, atom_invariants, ecfp, ecfp_with_bitinfo,
    ecfp_with_bitinfo_and_mode, ecfp_with_bitinfo_rdkit_environment_experimental,
    ecfp_with_invariant_mode, ecfp4, ecfp4_rdkit_environment_experimental, ecfp4_rdkit_invariants,
    ecfp6, ecfp6_rdkit_environment_experimental, ecfp6_rdkit_invariants, morgan_fp_counts,
    tanimoto_ecfp4,
};
pub use rdkit_atom_pair::{
    rdkit_atom_pair_counts, rdkit_atom_pair_fp, rdkit_atom_pair_sparse_counts,
};
pub use rdkit_avalon::{RdkitAvalonError, rdkit_avalon_fp};
pub use rdkit_layered::rdkit_layered_fp;
pub use rdkit_pattern::rdkit_pattern_fp;
pub use rdkit_rdk::{RdkitRdkFingerprintError, rdkit_rdk_fp, rdkit_rdk_fp_ignoring_atoms};
pub use rdkit_torsion::{
    RdkitAtomCodeExplanation, RdkitTorsionDiagnosticError, explain_rdkit_atom_code,
    explain_rdkit_topological_torsion_code, rdkit_atom_code, rdkit_legacy_torsion_counts,
    rdkit_topological_torsion_path_code, rdkit_torsion_counts, rdkit_torsion_fp,
    rdkit_torsion_sparse_counts,
};
/// Diagnostic-only APIs, not meant for production use — a per-`(atom,
/// radius)` trace of chematic's real Morgan expansion, for the RDKit
/// environment-parity oracle (see `scripts/ecfp_rdkit_environment_parity.py`),
/// and a raw-identifier suppressed-emission dump for sparse-count-shape
/// validation (see `scripts/ecfp_rdkit_suppression_parity.py`). Gated behind
/// the `diagnostics` feature.
#[cfg(feature = "diagnostics")]
#[doc(hidden)]
pub mod diagnostics {
    pub use crate::ecfp_diagnostics::{MorganTraceEntry, atom_ball, morgan_trace};
    pub use crate::morgan_environment::suppressed_environments_diagnostic;
    pub use crate::rdkit_morgan_hash::{RdkitMorganRawTraceEntry, rdkit_morgan_raw_trace};
}
pub use erg::{
    ERG_VEC_LEN, ErgAtomType, ErgBondType, ErgConfig, ErgFingerprint, cosine_erg_vec, erg,
    erg_extended, erg_vec, erg_with_config, tanimoto_erg, tanimoto_erg_vec,
};
pub use fcfp::{fcfp, fcfp_with_bitinfo, fcfp4, fcfp6, tanimoto_fcfp4};
pub use fps::{FpsError, FpsHeader, FpsReader, FpsRecord, FpsWriter};
pub use hdf::{HdfConfig, HdfFp, cosine_hdf, hdf, hdf_default};
pub use layered::{layered_fp, layered_fp_by_layer, tanimoto_layered};
pub use lsh::MhfpLshIndex;
pub use maccs::maccs;
pub use map4::{Map4Config, map4, map4_default, tanimoto_map4};
pub use mhfp::{MhfpConfig, MhfpFingerprint, mhfp, mhfp_128, mhfp_with_config, tanimoto_mhfp};
pub use path::{RdkitPathConfig, rdkit_path_fp, rdkit_path_fp_with_config, tanimoto_rdkit_path};
pub use pattern::{pattern_fp, tanimoto_pattern};
pub use pharmacophore_fp::{
    pharmacophore_feature_counts, pharmacophore_fp_2d, tanimoto_pharmacophore_2d,
};
pub use rdkit_morgan_config::{
    RdkitMorganConfig, RdkitMorganFingerprint, RdkitMorganFpSize, RdkitMorganRadius,
    rdkit_morgan_bitvec, rdkit_morgan_count_simulation, rdkit_morgan_fingerprint,
};
pub use rdkit_morgan_ecfp4::{
    PreparedRdkitMorganEcfp4, RdkitMorganEcfp4, RdkitMorganError, prepare_rdkit_morgan_ecfp4,
    rdkit_morgan_ecfp4_bitvec, rdkit_morgan_ecfp4_experimental,
};
pub use reaction_fp::{
    ReactionFingerprint, ReactionFpConfig, reaction_fp, reaction_fp_ecfp4, reaction_fp_with_config,
    tanimoto_reaction_fp,
};
pub use search::{
    FpType, PreparedFingerprintError, PreparedFingerprintIndex, nearest_neighbors,
    nearest_neighbors_from_fp, try_nearest_neighbors,
};
pub use topo_path::{TopoPathConfig, tanimoto_topo_path, topo_path};

/// The RDKit-corrected view as RDKit's bond-typed fingerprints see it: a
/// ring triple bond RDKit flags aromatic (`c1ccccc#1`, kept as a triple
/// bond in the view) counts as aromatic.
pub(crate) fn rdkit_fp_view(
    view: &chematic_core::Molecule,
) -> std::borrow::Cow<'_, chematic_core::Molecule> {
    use chematic_core::BondOrder;
    let aromatic_triples: Vec<chematic_core::BondIdx> = view
        .bonds()
        .filter(|(_, b)| {
            b.order == BondOrder::Triple
                && view.atom(b.atom1).aromatic
                && view.atom(b.atom2).aromatic
        })
        .map(|(i, _)| i)
        .collect();
    if aromatic_triples.is_empty() {
        return std::borrow::Cow::Borrowed(view);
    }
    let mut out = view.clone();
    for b in aromatic_triples {
        out.set_bond_order(b, BondOrder::Aromatic);
    }
    std::borrow::Cow::Owned(out)
}

/// RDKit's atomic number of an atom: 0 for a dummy atom, which chematic
/// stores with a placeholder element.
pub(crate) fn rdkit_atomic_num(mol: &chematic_core::Molecule, idx: chematic_core::AtomIdx) -> u32 {
    let atom = mol.atom(idx);
    if atom.wildcard {
        0
    } else {
        u32::from(atom.element.atomic_number())
    }
}
#[cfg(test)]
mod avalon_boundary_contract_tests;
