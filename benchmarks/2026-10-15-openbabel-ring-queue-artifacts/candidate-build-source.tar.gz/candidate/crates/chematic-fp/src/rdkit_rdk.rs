//! RDKit-compatible "RDKit fingerprint" port (`Chem.RDKFingerprint` / `RDKFingerprintMol`).
//!
//! Ported from RDKit's `Code/GraphMol/Fingerprints/{Fingerprints,RDKitFPGenerator,
//! FingerprintGenerator,FingerprintUtil,Subgraphs}.cpp`, default parameters
//! (`minPath=1, maxPath=7, useHs=true, branchedPaths=true, useBondOrder=true,
//! fpSize=2048, numBitsPerFeature=2`).
//!
//! # Algorithm
//!
//! 1. Enumerate every connected branched subgraph (not just linear paths) of
//!    1..=7 bonds via [`find_all_subgraphs`], RDKit's own canonical
//!    "root at minimum bond index" backtracking scheme
//!    (`Subgraphs::findAllSubgraphsOfLengthsMtoN`/`recurseWalkRange`): bonds are
//!    tried as roots in ascending index order, each root is marked globally
//!    forbidden once used (so no later root's subgraph ever reincludes it, which
//!    is what deduplicates the enumeration to exactly one discovery per subgraph),
//!    while a growing candidate frontier (adjacent, not-yet-forbidden bonds) is
//!    extended depth-first with a fresh forbidden-set copy handed to each
//!    recursive call (so sibling branches within one root don't interfere).
//! 2. For each subgraph (a set of bond indices), compute a per-bond hash
//!    (`RDKitFPUtils::generateBondHashes`): atom invariant is
//!    `(atomic_number % 128) << 1 | is_aromatic`; the *degree* folded into the
//!    hash is **path-local** (how many times the atom appears as a bond endpoint
//!    within this specific subgraph), not the molecule's true degree — confirmed
//!    against a live RDKit oracle, since a naive "true molecular degree" hash
//!    does not reproduce RDKit's output for `CCC`. The two atoms of a bond are
//!    canonically ordered (larger invariant first, ties broken by larger local
//!    degree first) before folding, so a bond's hash doesn't depend on which
//!    direction it was traversed from.
//! 3. Fold each subgraph's bond hashes (plus a trailing distinct-atom count, to
//!    distinguish e.g. `C1CC1` from `CC(C)C`) into one `u32` seed via RDKit's
//!    `gboost::hash_combine`/`hash_range` — despite the C++ call site declaring
//!    a 64-bit `unsigned long`, `gboost`'s own `hash_result_t` typedef is
//!    `std::uint32_t`, so the fold is pure 32-bit arithmetic with no width
//!    mismatch (confirmed against a live oracle for both 1-bond and 2-bond
//!    paths). A single-bond subgraph skips the sort/fold and uses its own bond
//!    hash directly as the seed.
//! 4. Each seed sets one direct bit (`seed % fpSize`) plus, since RDKit's
//!    default `numBitsPerFeature=2`, one additional bit drawn from a **weakened**
//!    Mersenne Twister reseeded with that exact `seed` (see
//!    [`RdkitWeakMt19937`]) via `boost::uniform_int<>(0, INT_MAX)`, which for
//!    this exact engine-range-vs-target-range ratio reduces to `raw / 2`
//!    (bucket division, not modulo — confirmed against a live oracle), then
//!    `% fpSize` again.
//!
//! # Aromaticity: literal vs. re-perceived
//!
//! RDKit's parser always normalizes a perceived-aromatic bond's type to
//! `AROMATIC` and sets `atom->getIsAromatic()`, regardless of whether the input
//! SMILES used Kekulé or lowercase-aromatic notation. chematic's SMILES parser
//! instead preserves a Kekulized input's literal bond orders verbatim (round-trip
//! fidelity). Reusing the exact fix already proven for `rdkit_pattern_fp` (see
//! that module's own doc comment): if a molecule has *any* literal
//! `BondOrder::Aromatic` bond, every bond's own literal order/every atom's own
//! literal `aromatic` flag is trusted as-is; only when a molecule has *zero*
//! literal aromatic bonds anywhere does this fall back to re-perceiving
//! aromaticity via [`chematic_perception::aromaticity::assign_aromaticity_ex`].
//! Re-perceiving unconditionally regressed a Kekulé-written, genuinely
//! non-aromatic ring that coexisted with a lowercase-aromatic ring elsewhere in
//! the same molecule; this hybrid rule avoids that without losing the fix for
//! molecules parsed entirely from Kekulé notation.
//!
//! # Verified
//!
//! Bit-exact (identical on-bit sets, not just popcount) against a live RDKit
//! oracle (`Chem.RDKFingerprint(mol, minPath=1, maxPath=7, fpSize=2048)`):
//! 100% on the full `descriptor_census_corpus.smi` (5000/5000) and
//! `chembl_accuracy_corpus_4999.smi` (5000/5000), 99.44% on
//! `nci_first_5k_smiles_only.smi` (4963/4991). Every one of the 28 NCI
//! mismatches is a fused polyheteroaromatic dye (xanthene/anthraquinone with
//! halogen substituents, phenothiazine/phenoxazinium, purine/xanthine-fused
//! rings), an exotic charged aromatic heterocycle (pyrylium/thiopyrylium-like
//! N+/O+/S+ ring atoms), or a metal-coordination complex (ferrocene-like
//! sandwich structures, ring-N-to-metal dative bonding) where chematic's own
//! `chematic-perception` Hückel aromaticity model does not (yet) recognize the
//! same aromatic system RDKit's does — the same pre-existing, out-of-scope
//! dependency gap already documented for `rdkit_torsion_fp`/`rdkit_atom_pair_fp`
//! (hypervalent-atom hybridization) and `rdkit_pattern_fp` (their own NCI
//! residuals), not a defect introduced by this port.

use crate::bitvec::BitVec2048;
use chematic_core::{AtomIdx, BondIdx, BondOrder, Molecule};
use chematic_perception::aromaticity::{
    AromaticityAlgorithm, AromaticityModel, assign_aromaticity_ex,
};
#[cfg(test)]
use rustc_hash::{FxHashMap, FxHashSet};
#[cfg(test)]
use std::collections::BTreeMap;

const FP_SIZE: u32 = 2048;
const MIN_PATH: usize = 1;
const MAX_PATH: usize = 7;
const NUM_BITS_PER_FEATURE: u32 = 2;

/// Invalid input to [`rdkit_rdk_fp_ignoring_atoms`].
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct RdkitRdkFingerprintError {
    /// Atom index supplied by the caller.
    pub atom: AtomIdx,
    /// Number of atoms in the input molecule.
    pub atom_count: usize,
}

impl core::fmt::Display for RdkitRdkFingerprintError {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        write!(
            f,
            "ignored atom index {} is out of range for a molecule with {} atoms",
            self.atom.0, self.atom_count
        )
    }
}

impl std::error::Error for RdkitRdkFingerprintError {}

fn hash_combine(seed: u32, value: u32) -> u32 {
    seed ^ value
        .wrapping_add(0x9e3779b9)
        .wrapping_add(seed << 6)
        .wrapping_add(seed >> 2)
}

fn rdkit_bond_type_code(order: BondOrder) -> u32 {
    match order {
        BondOrder::Single
        | BondOrder::Up
        | BondOrder::Down
        | BondOrder::QueryAny
        | BondOrder::QuerySingleOrDouble
        | BondOrder::QuerySingleOrAromatic
        | BondOrder::QueryDoubleOrAromatic => 1,
        BondOrder::Double => 2,
        BondOrder::Triple => 3,
        BondOrder::Quadruple => 4,
        BondOrder::Aromatic => 12,
        BondOrder::Dative => 17,
        BondOrder::Zero => 21,
    }
}

fn is_atom_aromatic(mol: &Molecule, aromaticity: Option<&AromaticityModel>, idx: AtomIdx) -> bool {
    if mol.atom(idx).aromatic {
        return true;
    }
    match aromaticity {
        Some(model) => model.is_atom_aromatic(idx),
        None => false,
    }
}

fn bond_type_for(mol: &Molecule, aromaticity: Option<&AromaticityModel>, bidx: BondIdx) -> u32 {
    let bond = mol.bond(bidx);
    let is_aromatic = bond.order == BondOrder::Aromatic
        || matches!(aromaticity, Some(model) if model.is_bond_aromatic(bidx));
    if is_aromatic {
        12
    } else {
        rdkit_bond_type_code(bond.order)
    }
}

/// RDKit's weakened Mersenne Twister variant used when `numBitsPerFeature > 1`.
///
/// `n=4, m=2, r=31` state — a deliberately tiny-state MT chosen by RDKit's
/// authors because reseeding a full MT19937 (n=624) per fingerprint feature is
/// too expensive. Critically, boost's *deprecated* `mersenne_twister<>` wrapper
/// class (the one RDKit's typedef actually instantiates) silently discards its
/// own last template parameter — RDKit's source passes `3346425566U` there,
/// presumably intending it as the seeding multiplier — and hardcodes the
/// textbook MT19937 multiplier `1812433253` instead (confirmed by reading
/// boost's `mersenne_twister.hpp` directly: the wrapper forwards to
/// `mersenne_twister_engine<..., 1812433253>` unconditionally). Do **not**
/// "fix" this to `3346425566` — that would silently break bit-exactness with
/// real RDKit output, which is itself built against the same boost quirk.
struct RdkitWeakMt19937 {
    state: [u32; 4],
    index: usize,
}

const MT_N: usize = 4;
const MT_M: usize = 2;
const MT_MATRIX_A: u32 = 0x9908b0df;
const MT_UPPER_MASK: u32 = 0x8000_0000;
const MT_LOWER_MASK: u32 = 0x7fff_ffff;
const MT_TEMPER_U: u32 = 11;
const MT_TEMPER_S: u32 = 7;
const MT_TEMPER_B: u32 = 0x9d2c_5680;
const MT_TEMPER_T: u32 = 15;
const MT_TEMPER_C: u32 = 0xefc6_0000;
const MT_TEMPER_L: u32 = 18;
const MT_SEED_MULT: u32 = 1_812_433_253;

impl RdkitWeakMt19937 {
    fn seeded(value: u32) -> Self {
        let mut state = [0u32; MT_N];
        state[0] = value;
        for i in 1..MT_N {
            state[i] = MT_SEED_MULT
                .wrapping_mul(state[i - 1] ^ (state[i - 1] >> 30))
                .wrapping_add(i as u32);
        }
        Self { state, index: MT_N }
    }

    fn twist(&mut self) {
        for j in 0..MT_N {
            let y = (self.state[j] & MT_UPPER_MASK) | (self.state[(j + 1) % MT_N] & MT_LOWER_MASK);
            let mut next = self.state[(j + MT_M) % MT_N] ^ (y >> 1);
            if y & 1 != 0 {
                next ^= MT_MATRIX_A;
            }
            self.state[j] = next;
        }
        self.index = 0;
    }

    fn next_u32(&mut self) -> u32 {
        if self.index == MT_N {
            self.twist();
        }
        let mut z = self.state[self.index];
        self.index += 1;
        z ^= z >> MT_TEMPER_U;
        z ^= (z << MT_TEMPER_S) & MT_TEMPER_B;
        z ^= (z << MT_TEMPER_T) & MT_TEMPER_C;
        z ^= z >> MT_TEMPER_L;
        z
    }
}

#[cfg(test)]
fn build_bond_adjacency(mol: &Molecule) -> FxHashMap<u32, Vec<u32>> {
    let mut nbrs: FxHashMap<u32, Vec<u32>> = FxHashMap::default();
    for (bidx, _) in mol.bonds() {
        nbrs.entry(bidx.0).or_default();
    }
    for (aidx, _) in mol.atoms() {
        let incident: Vec<u32> = mol.neighbors(aidx).map(|(_, b)| b.0).collect();
        for &b1 in &incident {
            for &b2 in &incident {
                if b1 != b2 {
                    nbrs.get_mut(&b1).unwrap().push(b2);
                }
            }
        }
    }
    nbrs
}

#[cfg(test)]
/// RDKit's `Subgraphs::findAllSubgraphsOfLengthsMtoN`/`recurseWalkRange`: every
/// connected subgraph of `min_len..=max_len` bonds, each discovered exactly
/// once (rooted at its lowest-index bond). Order within each length's `Vec` is
/// irrelevant to the caller (only the resulting bitset is observable), so this
/// need only reproduce the same *set* of subgraphs, not RDKit's exact
/// traversal order.
fn find_all_subgraphs(
    mol: &Molecule,
    min_len: usize,
    max_len: usize,
) -> BTreeMap<usize, Vec<Vec<u32>>> {
    let nbrs = build_bond_adjacency(mol);
    let n_bonds = mol.bond_count();
    let mut forbidden = vec![false; n_bonds];
    let mut res: BTreeMap<usize, Vec<Vec<u32>>> =
        (min_len..=max_len).map(|l| (l, Vec::new())).collect();

    for root in 0..n_bonds as u32 {
        if forbidden[root as usize] {
            continue;
        }
        forbidden[root as usize] = true;
        let cands = nbrs.get(&root).cloned().unwrap_or_default();
        let spath = vec![root];
        recurse_walk_range(
            &nbrs,
            spath,
            cands,
            min_len,
            max_len,
            forbidden.clone(),
            &mut res,
        );
    }
    res
}

#[cfg(test)]
fn recurse_walk_range(
    nbrs: &FxHashMap<u32, Vec<u32>>,
    spath: Vec<u32>,
    mut cands: Vec<u32>,
    min_len: usize,
    max_len: usize,
    mut forbidden: Vec<bool>,
    res: &mut BTreeMap<usize, Vec<Vec<u32>>>,
) {
    let nsize = spath.len();
    if nsize >= min_len && nsize <= max_len {
        res.get_mut(&nsize).unwrap().push(spath.clone());
    }
    if nsize >= max_len {
        return;
    }
    while let Some(next) = cands.pop() {
        if !forbidden[next as usize] {
            forbidden[next as usize] = true;
            let mut tstack = cands.clone();
            if let Some(next_nbrs) = nbrs.get(&next) {
                for &b in next_nbrs {
                    if !forbidden[b as usize] {
                        tstack.push(b);
                    }
                }
            }
            let mut tpath = spath.clone();
            tpath.push(next);
            recurse_walk_range(
                nbrs,
                tpath,
                tstack,
                min_len,
                max_len,
                forbidden.clone(),
                res,
            );
        }
    }
}

#[cfg(test)]
fn path_bond_hashes(
    mol: &Molecule,
    invariants: &[u32],
    aromaticity: Option<&AromaticityModel>,
    path: &[u32],
) -> (Vec<u32>, u32) {
    let mut atom_degrees: FxHashMap<u32, u32> = FxHashMap::default();
    let mut atoms_in_path: FxHashSet<u32> = FxHashSet::default();
    for &bidx in path {
        let bond = mol.bond(BondIdx(bidx));
        *atom_degrees.entry(bond.atom1.0).or_insert(0) += 1;
        *atom_degrees.entry(bond.atom2.0).or_insert(0) += 1;
        atoms_in_path.insert(bond.atom1.0);
        atoms_in_path.insert(bond.atom2.0);
    }

    let mut bond_nbrs = vec![0u32; path.len()];
    for i in 0..path.len() {
        let bi = mol.bond(BondIdx(path[i]));
        for j in (i + 1)..path.len() {
            let bj = mol.bond(BondIdx(path[j]));
            if bi.atom1 == bj.atom1
                || bi.atom1 == bj.atom2
                || bi.atom2 == bj.atom1
                || bi.atom2 == bj.atom2
            {
                bond_nbrs[i] += 1;
                bond_nbrs[j] += 1;
            }
        }
    }

    let mut bond_hashes = Vec::with_capacity(path.len());
    for (i, &bidx) in path.iter().enumerate() {
        let bond = mol.bond(BondIdx(bidx));
        let mut a1_hash = invariants[bond.atom1.0 as usize];
        let mut a2_hash = invariants[bond.atom2.0 as usize];
        let mut deg1 = atom_degrees[&bond.atom1.0];
        let mut deg2 = atom_degrees[&bond.atom2.0];
        if a1_hash < a2_hash {
            std::mem::swap(&mut a1_hash, &mut a2_hash);
            std::mem::swap(&mut deg1, &mut deg2);
        } else if a1_hash == a2_hash && deg1 < deg2 {
            std::mem::swap(&mut deg1, &mut deg2);
        }
        let bond_type = bond_type_for(mol, aromaticity, BondIdx(bidx));
        let mut h = bond_nbrs[i];
        h = hash_combine(h, bond_type);
        h = hash_combine(h, a1_hash);
        h = hash_combine(h, deg1);
        h = hash_combine(h, a2_hash);
        h = hash_combine(h, deg2);
        bond_hashes.push(h);
    }
    (bond_hashes, atoms_in_path.len() as u32)
}

#[cfg(test)]
fn path_seed(bond_hashes: &[u32], distinct_atoms: u32) -> u32 {
    if bond_hashes.len() == 1 {
        return bond_hashes[0];
    }
    let mut sorted = bond_hashes.to_vec();
    sorted.sort_unstable();
    sorted.push(distinct_atoms);
    let mut seed = 0u32;
    for v in sorted {
        seed = hash_combine(seed, v);
    }
    seed
}

/// Compute the RDKit-compatible "RDKit fingerprint" (`Chem.RDKFingerprint`).
///
/// See the module doc comment for the full algorithm and its verification
/// status.
pub fn rdkit_rdk_fp(mol: &Molecule) -> BitVec2048 {
    chematic_smiles::with_rdkit_model_molecule(mol, rdkit_rdk_fp_impl)
}

fn rdkit_rdk_fp_impl(mol: &Molecule) -> BitVec2048 {
    rdkit_rdk_fp_impl_ignoring_atoms(mol, &[])
}

/// Compute RDKit 2026.09.1's RDK fingerprint while excluding every
/// branched path that contains one of `ignored_atoms`.
///
/// This is the `ignoreAtoms` behavior added to
/// `RDKitFingerprintGenerator` in RDKit 2026.09.1. Atom indices refer to the
/// caller's molecule. Duplicate indices are harmless; an out-of-range index
/// is rejected instead of being ignored silently. The empty set produces the
/// same bits as [`rdkit_rdk_fp`].
pub fn rdkit_rdk_fp_ignoring_atoms(
    mol: &Molecule,
    ignored_atoms: &[AtomIdx],
) -> Result<BitVec2048, RdkitRdkFingerprintError> {
    for &atom in ignored_atoms {
        if atom.0 as usize >= mol.atom_count() {
            return Err(RdkitRdkFingerprintError {
                atom,
                atom_count: mol.atom_count(),
            });
        }
    }
    if ignored_atoms.is_empty() {
        return Ok(rdkit_rdk_fp(mol));
    }

    // `with_rdkit_model_molecule()` removes graph hydrogens when modelling
    // `Chem.MolFromSmiles`. Keep caller-facing indices meaningful by mapping
    // every retained atom back to the input before fingerprinting that model.
    if let Some((model, kept_input_atoms)) =
        chematic_smiles::rdkit_hydrogen_suppressed_with_map(mol)
    {
        let ignored_input: std::collections::HashSet<usize> =
            ignored_atoms.iter().map(|atom| atom.0 as usize).collect();
        let mapped: Vec<AtomIdx> = kept_input_atoms
            .iter()
            .enumerate()
            .filter_map(|(model_index, input_index)| {
                ignored_input
                    .contains(input_index)
                    .then_some(AtomIdx(model_index as u32))
            })
            .collect();
        return Ok(rdkit_rdk_fp_impl_ignoring_atoms(&model, &mapped));
    }

    Ok(chematic_smiles::with_rdkit_model_molecule(mol, |model| {
        debug_assert_eq!(model.atom_count(), mol.atom_count());
        rdkit_rdk_fp_impl_ignoring_atoms(model, ignored_atoms)
    }))
}

fn rdkit_rdk_fp_impl_ignoring_atoms(mol: &Molecule, ignored_atoms: &[AtomIdx]) -> BitVec2048 {
    // Where chematic's own aromaticity may disagree with RDKit's, read the
    // RDKit-corrected parity view (aromatic flags and bond orders as RDKit
    // sanitizes them) instead of re-perceiving.
    if chematic_perception::rdkit_model_may_disagree(mol)
        && let Ok(view) = chematic_perception::apply_aromaticity_rdkit_parity_shared(mol).as_ref()
    {
        return rdkit_rdk_fp_input(&crate::rdkit_fp_view(view), true, ignored_atoms);
    }
    // RDKit fingerprints its sanitized graph: perchlorate as
    // `[Cl+3]([O-])3O`, organometallic dative bonds
    // ([`chematic_perception::rdkit_sanitize_cleanup`]).
    if let Some(cleaned) = chematic_perception::rdkit_sanitize_cleanup(mol) {
        return rdkit_rdk_fp_input(&cleaned, false, ignored_atoms);
    }
    rdkit_rdk_fp_input(mol, false, ignored_atoms)
}

/// [`rdkit_rdk_fp`] on the graph RDKit sees.
fn rdkit_rdk_fp_input(mol: &Molecule, trust_view: bool, ignored_atoms: &[AtomIdx]) -> BitVec2048 {
    let mut fp = BitVec2048::new();
    if mol.atom_count() == 0 {
        return fp;
    }

    let has_literal_aromatic_bond =
        trust_view || mol.bonds().any(|(_, b)| b.order == BondOrder::Aromatic);
    let aromaticity = if has_literal_aromatic_bond {
        None
    } else {
        Some(assign_aromaticity_ex(mol, AromaticityAlgorithm::RdkitLike))
    };

    let invariants: Vec<u32> = (0..mol.atom_count())
        .map(|i| {
            let idx = AtomIdx(i as u32);
            let an = crate::rdkit_atomic_num(mol, idx);
            ((an % 128) << 1) | (is_atom_aromatic(mol, aromaticity.as_ref(), idx) as u32)
        })
        .collect();
    let bond_types: Vec<u32> = (0..mol.bond_count())
        .map(|b| bond_type_for(mol, aromaticity.as_ref(), BondIdx(b as u32)))
        .collect();
    let ends: Vec<(u32, u32)> = mol.bonds().map(|(_, b)| (b.atom1.0, b.atom2.0)).collect();
    // Every connected subgraph of MIN_PATH..=MAX_PATH bonds is hashed as it
    // is discovered; only the set of subgraphs (not their order or count) is
    // observable in the bit vector.
    let mut walker = SubgraphWalker::new(mol, ignored_atoms);
    walker.for_each(MIN_PATH, MAX_PATH, |path, degree, n_atoms| {
        let seed = path_seed_small(path, &ends, &invariants, &bond_types, degree, n_atoms);
        fp.set((seed % FP_SIZE) as usize);
        if NUM_BITS_PER_FEATURE > 1 {
            let mut mt = RdkitWeakMt19937::seeded(seed);
            for _ in 1..NUM_BITS_PER_FEATURE {
                let raw = mt.next_u32();
                let bounded = raw / 2;
                fp.set((bounded % FP_SIZE) as usize);
            }
        }
    });

    fp
}

/// [`path_bond_hashes`] + [`path_seed`] for one subgraph of at most
/// `MAX_PATH` bonds, on stack buffers. `degree[a]` is atom `a`'s degree
/// within the path and `n_atoms` the number of atoms the path touches.
fn path_seed_small(
    path: &[u32],
    ends: &[(u32, u32)],
    invariants: &[u32],
    bond_types: &[u32],
    degree: &[u32],
    n_atoms: u32,
) -> u32 {
    debug_assert!(!path.is_empty() && path.len() <= MAX_PATH);
    let len = path.len();
    let mut hashes = [0u32; MAX_PATH];
    for (i, &b) in path.iter().enumerate() {
        let (a1, a2) = ends[b as usize];
        let mut a1_hash = invariants[a1 as usize];
        let mut a2_hash = invariants[a2 as usize];
        let mut deg1 = degree[a1 as usize];
        let mut deg2 = degree[a2 as usize];
        // Other path bonds sharing an endpoint (no two bonds share both).
        let bond_nbrs = deg1 + deg2 - 2;
        if a1_hash < a2_hash {
            std::mem::swap(&mut a1_hash, &mut a2_hash);
            std::mem::swap(&mut deg1, &mut deg2);
        } else if a1_hash == a2_hash && deg1 < deg2 {
            std::mem::swap(&mut deg1, &mut deg2);
        }
        let mut h = bond_nbrs;
        h = hash_combine(h, bond_types[b as usize]);
        h = hash_combine(h, a1_hash);
        h = hash_combine(h, deg1);
        h = hash_combine(h, a2_hash);
        h = hash_combine(h, deg2);
        hashes[i] = h;
    }
    if len == 1 {
        return hashes[0];
    }
    let sorted = &mut hashes[..len];
    sorted.sort_unstable();
    let mut seed = 0u32;
    for &v in sorted.iter() {
        seed = hash_combine(seed, v);
    }
    hash_combine(seed, n_atoms)
}

/// Allocation-free [`find_all_subgraphs`]: the same recursive walk, with the
/// per-call copies of the forbidden flags replaced by an undo log and the
/// candidate stacks kept in per-depth buffers. Visits the same set of
/// subgraphs, each once.
struct SubgraphWalker {
    nbrs: Vec<Vec<u32>>,
    ends: Vec<(u32, u32)>,
    forbidden: Vec<bool>,
    undo: Vec<u32>,
    stacks: Vec<Vec<u32>>,
    path: Vec<u32>,
    /// Degree of every atom within the current path, and how many atoms
    /// have a nonzero one.
    degree: Vec<u32>,
    n_atoms: u32,
}

impl SubgraphWalker {
    fn new(mol: &Molecule, ignored_atoms: &[AtomIdx]) -> Self {
        let n_bonds = mol.bond_count();
        // Same lists as `build_bond_adjacency`, indexed by bond.
        let mut nbrs: Vec<Vec<u32>> = vec![Vec::new(); n_bonds];
        for (aidx, _) in mol.atoms() {
            let incident = mol.neighbor_slice(aidx);
            for &(_, b1) in incident {
                for &(_, b2) in incident {
                    if b1 != b2 {
                        nbrs[b1.0 as usize].push(b2.0);
                    }
                }
            }
        }
        let mut forbidden = vec![false; n_bonds];
        if !ignored_atoms.is_empty() {
            let mut ignored = vec![false; mol.atom_count()];
            for &atom in ignored_atoms {
                ignored[atom.0 as usize] = true;
            }
            for (bond_index, bond) in mol.bonds() {
                if ignored[bond.atom1.0 as usize] || ignored[bond.atom2.0 as usize] {
                    forbidden[bond_index.0 as usize] = true;
                }
            }
        }
        Self {
            nbrs,
            ends: mol.bonds().map(|(_, b)| (b.atom1.0, b.atom2.0)).collect(),
            forbidden,
            undo: Vec::new(),
            stacks: vec![Vec::new(); MAX_PATH + 2],
            path: Vec::with_capacity(MAX_PATH + 1),
            degree: vec![0; mol.atom_count()],
            n_atoms: 0,
        }
    }

    fn push_bond(&mut self, b: u32) {
        self.path.push(b);
        let (a1, a2) = self.ends[b as usize];
        for a in [a1, a2] {
            let d = &mut self.degree[a as usize];
            if *d == 0 {
                self.n_atoms += 1;
            }
            *d += 1;
        }
    }

    fn pop_bond(&mut self) {
        let b = self.path.pop().expect("non-empty path");
        let (a1, a2) = self.ends[b as usize];
        for a in [a1, a2] {
            let d = &mut self.degree[a as usize];
            *d -= 1;
            if *d == 0 {
                self.n_atoms -= 1;
            }
        }
    }

    fn for_each(
        &mut self,
        min_len: usize,
        max_len: usize,
        mut visit: impl FnMut(&[u32], &[u32], u32),
    ) {
        let n_bonds = self.nbrs.len();
        for root in 0..n_bonds as u32 {
            if self.forbidden[root as usize] {
                continue;
            }
            // Roots stay forbidden for every later root (as in the original).
            self.forbidden[root as usize] = true;
            self.push_bond(root);
            let mut stack = std::mem::take(&mut self.stacks[0]);
            stack.clear();
            stack.extend_from_slice(&self.nbrs[root as usize]);
            self.stacks[0] = stack;
            self.walk(0, min_len, max_len, &mut visit);
            self.pop_bond();
        }
    }

    /// One `recurse_walk_range` frame; `self.stacks[depth]` holds its
    /// candidate stack and `self.path` its subgraph.
    fn walk(
        &mut self,
        depth: usize,
        min_len: usize,
        max_len: usize,
        visit: &mut impl FnMut(&[u32], &[u32], u32),
    ) {
        let nsize = self.path.len();
        if nsize >= min_len && nsize <= max_len {
            visit(&self.path, &self.degree, self.n_atoms);
        }
        if nsize >= max_len {
            return;
        }
        let undo_mark = self.undo.len();
        while let Some(next) = self.stacks[depth].pop() {
            if self.forbidden[next as usize] {
                continue;
            }
            self.forbidden[next as usize] = true;
            self.undo.push(next);
            // Child stack: the remaining candidates, then `next`'s allowed
            // neighbors.
            let mut child = std::mem::take(&mut self.stacks[depth + 1]);
            child.clear();
            child.extend_from_slice(&self.stacks[depth]);
            for &b in &self.nbrs[next as usize] {
                if !self.forbidden[b as usize] {
                    child.push(b);
                }
            }
            self.stacks[depth + 1] = child;
            self.push_bond(next);
            self.walk(depth + 1, min_len, max_len, visit);
            self.pop_bond();
        }
        // Forbidden marks set by this frame were local to it (the original
        // passed each child a copy).
        for &b in &self.undo[undo_mark..] {
            self.forbidden[b as usize] = false;
        }
        self.undo.truncate(undo_mark);
    }
}

/// Tanimoto similarity between two RDKit-compatible RDK fingerprints.
pub fn tanimoto_rdkit_rdk(a: &BitVec2048, b: &BitVec2048) -> f64 {
    a.tanimoto(b)
}

#[cfg(test)]
mod tests {
    use super::*;
    use chematic_smiles::parse;

    fn mol(smiles: &str) -> Molecule {
        parse(smiles).unwrap_or_else(|e| panic!("failed to parse {smiles:?}: {e}"))
    }

    /// The original subgraph-list implementation (differential oracle).
    fn rdkit_rdk_fp_reference(mol: &Molecule) -> BitVec2048 {
        let mut fp = BitVec2048::new();
        if mol.atom_count() == 0 {
            return fp;
        }
        let has_literal_aromatic_bond = mol.bonds().any(|(_, b)| b.order == BondOrder::Aromatic);
        let aromaticity = if has_literal_aromatic_bond {
            None
        } else {
            Some(assign_aromaticity_ex(mol, AromaticityAlgorithm::RdkitLike))
        };
        let invariants: Vec<u32> = (0..mol.atom_count())
            .map(|i| {
                let idx = AtomIdx(i as u32);
                let an = mol.atom(idx).element.atomic_number() as u32;
                ((an % 128) << 1) | (is_atom_aromatic(mol, aromaticity.as_ref(), idx) as u32)
            })
            .collect();
        for plist in find_all_subgraphs(mol, MIN_PATH, MAX_PATH).values() {
            for path in plist {
                let (bond_hashes, distinct_atoms) =
                    path_bond_hashes(mol, &invariants, aromaticity.as_ref(), path);
                let seed = path_seed(&bond_hashes, distinct_atoms);
                fp.set((seed % FP_SIZE) as usize);
                let mut mt = RdkitWeakMt19937::seeded(seed);
                fp.set(((mt.next_u32() / 2) % FP_SIZE) as usize);
            }
        }
        fp
    }

    #[test]
    fn streaming_walk_matches_reference() {
        for smi in [
            "CC",
            "CC(C)(C)C",
            "c1ccccc1",
            "C1=CC=CC=C1",
            "CC(=O)Oc1ccccc1C(=O)O",
            "c1ccc2ccccc2c1",
            "C12C3C4C1C5C2C3C45",
            "CN1CCC23c4c5ccc(O)c4OC2C(O)C=CC3C1C5",
            "O=C1c2ccccc2C(=O)N1CCCCN1CCN(c2cccc3ccccc23)CC1",
            "[Na+].[Cl-].CCO",
        ] {
            let m = mol(smi);
            assert_eq!(rdkit_rdk_fp(&m), rdkit_rdk_fp_reference(&m), "{smi}");
        }
    }

    #[test]
    fn deterministic() {
        let m = mol("CC(=O)Oc1ccccc1C(=O)O");
        assert_eq!(rdkit_rdk_fp(&m), rdkit_rdk_fp(&m));
    }

    #[test]
    fn different_molecules_differ() {
        let a = rdkit_rdk_fp(&mol("CCO"));
        let b = rdkit_rdk_fp(&mol("c1ccccc1"));
        assert_ne!(a, b);
    }

    #[test]
    fn single_atom_has_no_bits() {
        let fp = rdkit_rdk_fp(&mol("C"));
        assert_eq!(fp.popcount(), 0);
    }

    fn on_bits(fp: &BitVec2048) -> Vec<usize> {
        (0..2048).filter(|&bit| fp.get(bit)).collect()
    }

    #[test]
    fn ignore_atoms_matches_rdkit_2026_09_1_oracle() {
        let cases: &[(&str, &[u32], &[usize])] = &[
            ("CCO", &[], &[562, 1183, 1308, 1339, 1728, 1772]),
            ("CCO", &[2], &[1308, 1772]),
            ("CCO", &[1], &[]),
            ("CCCO", &[2], &[1308, 1772]),
            (
                "c1ccccc1O",
                &[6],
                &[
                    103, 161, 194, 294, 330, 792, 842, 1026, 1287, 1784, 1889, 1907,
                ],
            ),
        ];
        for &(smiles, ignored, expected) in cases {
            let molecule = mol(smiles);
            let ignored: Vec<_> = ignored.iter().copied().map(AtomIdx).collect();
            let actual = rdkit_rdk_fp_ignoring_atoms(&molecule, &ignored).unwrap();
            assert_eq!(on_bits(&actual), expected, "{smiles}, ignored={ignored:?}");
        }
    }

    #[test]
    fn empty_ignore_set_preserves_existing_fingerprint() {
        let molecule = mol("CC(=O)Oc1ccccc1C(=O)O");
        assert_eq!(
            rdkit_rdk_fp_ignoring_atoms(&molecule, &[]).unwrap(),
            rdkit_rdk_fp(&molecule)
        );
    }

    #[test]
    fn ignored_graph_hydrogen_uses_input_atom_indices() {
        let molecule = mol("[H]O[H]");
        assert_eq!(
            rdkit_rdk_fp_ignoring_atoms(&molecule, &[AtomIdx(1)]).unwrap(),
            BitVec2048::new()
        );
        // Ignoring an H which RDKit suppresses does not accidentally mask O.
        assert_eq!(
            rdkit_rdk_fp_ignoring_atoms(&molecule, &[AtomIdx(0)]).unwrap(),
            rdkit_rdk_fp(&molecule)
        );
    }

    #[test]
    fn invalid_ignored_atom_is_rejected() {
        let molecule = mol("CCO");
        let error = rdkit_rdk_fp_ignoring_atoms(&molecule, &[AtomIdx(3)]).unwrap_err();
        assert_eq!(
            error,
            RdkitRdkFingerprintError {
                atom: AtomIdx(3),
                atom_count: 3,
            }
        );
    }

    #[test]
    fn matches_rdkit_oracle_on_hand_picked_molecules() {
        // (smiles, expected on-bit count from a live `Chem.RDKFingerprint`
        // oracle run at minPath=1, maxPath=7, fpSize=2048).
        let cases: &[(&str, u32)] = &[
            ("CC", 2),
            ("C=C", 2),
            ("C#C", 2),
            ("CCC", 4),
            ("CC(C)C", 6),
            ("c1ccccc1", 12),
            ("C1CC1", 6),
            ("CCO", 6),
            ("CC(=O)O", 14),
            ("c1ccc2ccccc2c1", 44),
            ("CC(=O)Oc1ccccc1C(=O)O", 354),
        ];
        for &(smiles, expected) in cases {
            let fp = rdkit_rdk_fp(&mol(smiles));
            assert_eq!(fp.popcount(), expected, "popcount mismatch for {smiles:?}");
        }
    }
}
