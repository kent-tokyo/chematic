//! RDKit-bit-exact Topological Torsion fingerprint (`GetHashedTopologicalTorsionFingerprintAsBitVect`).
//!
//! Opt-in `RdkitExact`-mode addition, kept fully separate from [`crate::atom_pair::torsion_fp`]
//! (chematic's own native, similarity-preserving-but-not-RDKit-identical scheme) --
//! neither function changes the other's behavior. First of the fingerprint-parity
//! series (Track A / 99-point directive Phase 6): Topological Torsion measured
//! closest to RDKit of the six priority fingerprints (avg. Hamming distance ~66/2048
//! on a 100-molecule sample, vs. 300-600+ for the other five), so it's the pattern
//! this module establishes for the rest.
//!
//! Derived from RDKit's C++ source (`Code/GraphMol/Fingerprints/FingerprintUtil.cpp`,
//! `AtomPairs.cpp`, `TopologicalTorsionGenerator.cpp`, `Atom.cpp`), commit pinned at
//! research time against `master` (RDKit 2026.03 series, matching this repo's
//! currently-installed `rdkit` package). Every constant/formula below is a direct
//! port, not a reinterpretation -- see each function's doc comment for the exact
//! C++ source it mirrors.
//!
//! **Status**: 87.2% bit-exact on a 1000-molecule general corpus sample
//! (`scripts/descriptor_census_corpus.smi`), verified against a live RDKit
//! oracle (`rdkit.Chem.AllChem.GetHashedTopologicalTorsionFingerprintAsBitVect`).
//! Two known, documented residual sources account for essentially all
//! remaining misses -- see [`num_pi_electrons`]'s doc comment (RDKit's
//! hybridization-gated pi-electron count for hypervalent atoms, e.g. P/S,
//! not replicated) and [`triangle_closure_paths`]'s doc comment
//! (asymmetrically-substituted 3-membered rings can need more than the one
//! closure entry this module generates). Three real bugs were found and
//! fixed reaching this point (0% -> 87.2%), each verified against the live
//! oracle before moving to the next: a missing `-2` "topological torsion
//! correction" on atom invariants, double-counted torsion paths inflating
//! count-simulation thresholds, and missing 3-membered-ring closure
//! entries entirely.

use chematic_core::{AtomIdx, BondOrder, Molecule};
use std::fmt;

use crate::bitvec::BitVec2048;
use crate::rdkit_morgan_hash::hash_vec;

// ---------------------------------------------------------------------------
// AtomPairs.h / FingerprintUtil.cpp constants
// ---------------------------------------------------------------------------

const NUM_TYPE_BITS: u32 = 4;
/// `AtomPairs::atomNumberTypes` -- a fixed, sorted 15-entry lookup table (16
/// slots, index 15 also serves as the "everything else" bucket). Atomic
/// numbers not in this list collapse to whichever bucket they'd sort into
/// (see [`atom_type_index`]) -- faithfully replicated, including the
/// surprising case where an atomic number below 5 (e.g. H, He) or above 53
/// (e.g. most metals) both collapse toward the boundary buckets, not a
/// dedicated "other" code.
const ATOM_NUMBER_TYPES: [u8; 15] = [5, 6, 7, 8, 9, 14, 15, 16, 17, 33, 34, 35, 51, 52, 53];
const NUM_PI_BITS: u32 = 2;
const MAX_NUM_PI: u32 = (1 << NUM_PI_BITS) - 1;
const NUM_BRANCH_BITS: u32 = 3;
const MAX_NUM_BRANCHES: u32 = (1 << NUM_BRANCH_BITS) - 1;
pub(crate) const CODE_SIZE: u32 = NUM_TYPE_BITS + NUM_PI_BITS + NUM_BRANCH_BITS;

/// Decoded fields of an RDKit atom-pair/topological-torsion atom code.
///
/// `branch_count` is the value encoded in the code. For a topological-torsion
/// path, use [`explain_rdkit_topological_torsion_code`] to restore the endpoint
/// and interior path corrections automatically.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct RdkitAtomCodeExplanation {
    pub symbol: &'static str,
    pub branch_count: u32,
    pub pi_electron_count: u32,
}

/// Input errors returned by the public atom-code diagnostic helpers.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RdkitTorsionDiagnosticError {
    AtomIndexOutOfRange { index: usize, atom_count: usize },
    EmptyPath,
    PathTooLong { size: usize, maximum: usize },
}

impl fmt::Display for RdkitTorsionDiagnosticError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::AtomIndexOutOfRange { index, atom_count } => write!(
                f,
                "atom index {index} is out of range for a molecule with {atom_count} atoms"
            ),
            Self::EmptyPath => f.write_str("topological-torsion path must not be empty"),
            Self::PathTooLong { size, maximum } => write!(
                f,
                "topological-torsion path has {size} atoms; at most {maximum} fit in a u64 code"
            ),
        }
    }
}

impl std::error::Error for RdkitTorsionDiagnosticError {}

/// Count-simulation thresholds (`AtomPairs.cpp`'s `bounds[4] = {1, 2, 4, 8}`),
/// used only when `nBitsPerEntry == 4` (the default, and the only mode this
/// module implements).
const COUNT_BOUNDS: [u32; 4] = [1, 2, 4, 8];
const N_BITS_PER_ENTRY: usize = 4;

/// `Atom.cpp`'s `numPiElectrons`: `1` for any aromatic atom (regardless of
/// stored bond orders); otherwise the sum, over every real (non-dative,
/// non-zero-order) bond, of `(bond_order_as_integer - 1)` -- i.e. 0 per
/// single bond, 1 per double, 2 per triple, 3 per quadruple. Dative and
/// zero-order bonds are excluded entirely (RDKit's `getValenceContrib(&atom)
/// != 0.0` guard), not merely counted as order-1.
///
/// **Known residual, NOT implemented here**: the real C++ function's
/// non-aromatic branch is additionally gated on `atom.getHybridization() !=
/// Atom::SP3` -- for an atom RDKit's hybridization-perception classifies as
/// SP3 despite carrying a formal double bond (confirmed via a live RDKit
/// oracle: a phosphinic-acid `P` atom in `[PH](=O)O`, `GetHybridization()
/// == SP3`, `GetNumPiElectrons() == 0` even though it has a `P=O` bond),
/// the real function returns 0 unconditionally, skipping the bond-order sum
/// entirely. This function has no hybridization gate at all, so it always
/// takes the bond-order-sum path once an atom has any multiple bond,
/// disagreeing with RDKit specifically for atoms RDKit perceives as SP3
/// under formal-multiple-bond bookkeeping (observed for hypervalent P/S;
/// not yet characterized exhaustively). Replicating this exactly requires
/// porting RDKit's own hybridization-perception algorithm -- chematic's
/// existing `chematic_chem::hybridization_per_atom` was checked and does
/// NOT match RDKit for this same case (reports SP2, not SP3), so it isn't a
/// drop-in fix either. Confirmed to be the dominant remaining source of
/// non-bit-exact output after the 3-membered-ring fix
/// ([`triangle_closure_paths`]) landed -- measured 87.2% bit-exact on a
/// 1000-molecule general corpus sample, with essentially all remaining
/// misses attributable to this gap or to asymmetrically-substituted
/// 3-membered rings (see that function's own doc comment).
pub(crate) fn num_pi_electrons(mol: &Molecule, idx: AtomIdx) -> u32 {
    // Where chematic's perception may disagree with RDKit's (hypervalent
    // atoms, metals, radicals, ...), RDKit's own count on its model.
    let rd = mol.derived(chematic_core::DerivedSlot::RdkitPiElectrons, || {
        if chematic_perception::rdkit_model_may_disagree(mol) {
            chematic_smiles::rdkit_num_pi_electrons(mol)
        } else {
            None
        }
    });
    if let Some(v) = rd.as_ref() {
        return v[idx.0 as usize];
    }
    let atom = mol.atom(idx);
    if atom.aromatic {
        return 1;
    }
    if rdkit_perceives_sp3(mol, idx) {
        return 0;
    }
    let mut total: i32 = 0;
    for (_, bidx) in mol.neighbors(idx) {
        let contribution = match mol.bond(bidx).order {
            BondOrder::Single | BondOrder::Up | BondOrder::Down | BondOrder::QueryAny => 1,
            BondOrder::Double => 2,
            BondOrder::Triple => 3,
            BondOrder::Quadruple => 4,
            BondOrder::Aromatic => 1,
            // Query bond orders never occur on a concrete (non-SMARTS) Molecule,
            // which is all this function is ever called on -- treated the same
            // as QueryAny for exhaustiveness, never actually reached.
            BondOrder::QuerySingleOrDouble
            | BondOrder::QuerySingleOrAromatic
            | BondOrder::QueryDoubleOrAromatic => 1,
            BondOrder::Zero | BondOrder::Dative => continue,
        };
        total += contribution - 1;
    }
    total.max(0) as u32
}

/// Outer-shell electron count (`PeriodicTable::getNouterElecs`) for the
/// main-group elements; `None` elsewhere (transition metals etc. keep the
/// historical behaviour).
fn main_group_outer_electrons(z: u8) -> Option<i32> {
    Some(match z {
        1 => 1,
        2 => 2,
        3..=10 => i32::from(z) - 2,
        11..=18 => i32::from(z) - 10,
        19 | 37 | 55 => 1,
        20 | 38 | 56 => 2,
        31..=36 => i32::from(z) - 28,
        49..=54 => i32::from(z) - 46,
        81..=86 => i32::from(z) - 78,
        _ => return None,
    })
}

/// Whether RDKit's `setHybridization` (ConjugHybrid.cpp) assigns `SP3` to a
/// non-aromatic atom, for the cases this module can decide exactly.
///
/// RDKit computes `norbs = totalDegree + lonePairs`, with
/// `lonePairs = (nOuter - (totalValence + charge)) / 2` at or above an octet,
/// and assigns `SP3` for `norbs == 4` unless the atom has at most three
/// neighbours (including H) *and* a conjugated bond. For a non-aromatic P/S/Se
/// style atom (`nOuter` 5 or 6, beyond the first row, degree >= 2)
/// `isAtomConjugCand` is false and its multiple bonds lead to terminal atoms,
/// so none of its bonds can be marked conjugated. Anything this function
/// cannot decide exactly (dative bonds, below-octet radical bookkeeping,
/// unknown outer shells, possibly conjugated first-row atoms) returns
/// `false`, i.e. the historical bond-order sum is used.
///
/// This closes the documented hypervalent-S/P residual: sulfonyl/sulfinyl,
/// phosphoryl and seleninyl centres are `SP3` in RDKit and therefore carry
/// zero pi electrons in the atom-pair/torsion atom code.
fn rdkit_perceives_sp3(mol: &Molecule, idx: AtomIdx) -> bool {
    let atom = mol.atom(idx);
    let z = atom.element.atomic_number();
    let Some(n_outer) = main_group_outer_electrons(z) else {
        return false;
    };
    let mut bond_valence = 0i32;
    let mut has_multiple = false;
    for (_, bidx) in mol.neighbors(idx) {
        bond_valence += match mol.bond(bidx).order {
            BondOrder::Single | BondOrder::Up | BondOrder::Down => 1,
            BondOrder::Double => {
                has_multiple = true;
                2
            }
            BondOrder::Triple => {
                has_multiple = true;
                3
            }
            BondOrder::Quadruple => {
                has_multiple = true;
                4
            }
            // Aromatic bonds on a non-aromatic atom, dative/zero-order and
            // query bonds: not decided here.
            _ => return false,
        };
    }
    if !has_multiple {
        return false; // num_pi_electrons is 0 either way
    }
    let hydrogens = i32::from(chematic_core::implicit_hcount(mol, idx));
    let total_valence = bond_valence + hydrogens;
    let charge = i32::from(atom.charge);
    if total_valence + n_outer - charge < 8 {
        return false; // below an octet: radical bookkeeping not modelled
    }
    let total_degree = mol.degree(idx) as i32 + hydrogens;
    let lone_pairs = (n_outer - (total_valence + charge)) / 2; // C++ truncation
    if total_degree + lone_pairs != 4 {
        return false;
    }
    if total_degree > 3 {
        return true;
    }
    z > 10 && (n_outer == 5 || n_outer == 6) && mol.degree(idx) >= 2
}

/// `AtomPairs::getAtomCode`: packs `[type:4][pi:2][branch:3]` (LSB-first) into
/// one `u32`, `branchSubtract` reducing the raw degree before the branch
/// field is computed (clamped to 0, never underflows). `includeChirality` is
/// not implemented here (this module targets `includeChirality=False`, the
/// default `GetHashedTopologicalTorsionFingerprintAsBitVect` call and this
/// crate's `mol.torsion_fp()`-equivalent scope) -- callers must not pass
/// `true`.
pub(crate) fn atom_code(mol: &Molecule, idx: AtomIdx, branch_subtract: u32) -> u32 {
    let atom = mol.atom(idx);
    let degree = mol.degree(idx) as u32;
    let num_branches = degree.saturating_sub(branch_subtract);
    let mut code = num_branches % MAX_NUM_BRANCHES;

    let n_pi = num_pi_electrons(mol, idx) % MAX_NUM_PI;
    code |= n_pi << NUM_BRANCH_BITS;

    // Dummy atoms have atomic number 0 (chematic stores them as C).
    let type_idx = atom_type_index(if atom.wildcard {
        0
    } else {
        atom.element.atomic_number()
    });
    code |= type_idx << (NUM_BRANCH_BITS + NUM_PI_BITS);

    code
}

/// Linear scan matching `getAtomCode`'s lookup loop exactly. The C++ array is
/// declared `atomNumberTypes[1 << numTypeBits]` (16 slots) but only 15 are
/// explicitly initialized -- the 16th (index 15) is implicitly zero, and the
/// loop bound is `nTypes = 1 << numTypeBits = 16`, not the initializer
/// list's length. First exact match wins; the first table entry *greater*
/// than `atomic_num` clamps `typeIdx` to `nTypes` then backs up to `nTypes -
/// 1 = 15` (the phantom zero slot, NOT index 14) -- same clamp target if the
/// scan runs off the end without a match. A literal port of the C++
/// early-break/clamp logic, phantom slot included.
fn atom_type_index(atomic_num: u8) -> u32 {
    const N_TYPES: usize = 1 << NUM_TYPE_BITS as usize;
    let table = |i: usize| -> u8 { ATOM_NUMBER_TYPES.get(i).copied().unwrap_or(0) };
    let mut type_idx = 0usize;
    while type_idx < N_TYPES {
        if table(type_idx) == atomic_num {
            break;
        } else if table(type_idx) > atomic_num {
            type_idx = N_TYPES;
            break;
        }
        type_idx += 1;
    }
    if type_idx == N_TYPES {
        type_idx -= 1;
    }
    type_idx as u32
}

/// Return RDKit's atom-pair atom code for one atom.
///
/// This is the interpretable invariant used by RDKit-compatible atom-pair and
/// topological-torsion fingerprints. `branch_subtract` is normally `0` for an
/// atom-pair code, `1` for a torsion endpoint, and `2` for a torsion interior
/// atom. The function is checked and never panics on a caller-supplied index.
pub fn rdkit_atom_code(
    mol: &Molecule,
    idx: AtomIdx,
    branch_subtract: u32,
) -> Result<u32, RdkitTorsionDiagnosticError> {
    let index = idx.0 as usize;
    if index >= mol.atom_count() {
        return Err(RdkitTorsionDiagnosticError::AtomIndexOutOfRange {
            index,
            atom_count: mol.atom_count(),
        });
    }
    Ok(atom_code(mol, idx, branch_subtract))
}

/// Decode an RDKit atom-pair/topological-torsion atom code.
pub fn explain_rdkit_atom_code(code: u32) -> RdkitAtomCodeExplanation {
    const SYMBOLS: [&str; 16] = [
        "B", "C", "N", "O", "F", "Si", "P", "S", "Cl", "As", "Se", "Br", "Sb", "Te", "I", "X",
    ];
    let branch_mask = (1u32 << NUM_BRANCH_BITS) - 1;
    let pi_mask = (1u32 << NUM_PI_BITS) - 1;
    let type_mask = (1u32 << NUM_TYPE_BITS) - 1;
    let branch_count = code & branch_mask;
    let pi_electron_count = (code >> NUM_BRANCH_BITS) & pi_mask;
    let type_index = ((code >> (NUM_BRANCH_BITS + NUM_PI_BITS)) & type_mask) as usize;
    RdkitAtomCodeExplanation {
        symbol: SYMBOLS[type_index],
        branch_count,
        pi_electron_count,
    }
}

/// Pack one caller-selected path into RDKit's legacy topological-torsion code.
///
/// Direction is canonicalized, so a path and its reverse have the same code.
/// Like RDKit's diagnostic `pyScorePath`, this helper intentionally does not
/// require adjacent or distinct atom indices: it explains the code-generation
/// primitive and leaves path enumeration to the fingerprint implementation.
pub fn rdkit_topological_torsion_path_code(
    mol: &Molecule,
    path: &[AtomIdx],
) -> Result<u64, RdkitTorsionDiagnosticError> {
    const MAX_PATH_SIZE: usize = u64::BITS as usize / CODE_SIZE as usize;
    if path.is_empty() {
        return Err(RdkitTorsionDiagnosticError::EmptyPath);
    }
    if path.len() > MAX_PATH_SIZE {
        return Err(RdkitTorsionDiagnosticError::PathTooLong {
            size: path.len(),
            maximum: MAX_PATH_SIZE,
        });
    }

    let mut codes = Vec::with_capacity(path.len());
    for (position, &idx) in path.iter().enumerate() {
        let branch_subtract = if position == 0 || position + 1 == path.len() {
            1
        } else {
            2
        };
        codes.push(rdkit_atom_code(mol, idx, branch_subtract)?);
    }
    if codes.iter().rev().cmp(codes.iter()).is_lt() {
        codes.reverse();
    }

    Ok(codes
        .into_iter()
        .enumerate()
        .fold(0u64, |packed, (position, code)| {
            packed | (u64::from(code) << (CODE_SIZE as usize * position))
        }))
}

/// Decode a legacy RDKit topological-torsion path code.
///
/// The returned branch counts are restored to the original molecular degree:
/// one is added at each endpoint and two at each interior position.
pub fn explain_rdkit_topological_torsion_code(
    mut code: u64,
    size: usize,
) -> Result<Vec<RdkitAtomCodeExplanation>, RdkitTorsionDiagnosticError> {
    const MAX_PATH_SIZE: usize = u64::BITS as usize / CODE_SIZE as usize;
    if size == 0 {
        return Err(RdkitTorsionDiagnosticError::EmptyPath);
    }
    if size > MAX_PATH_SIZE {
        return Err(RdkitTorsionDiagnosticError::PathTooLong {
            size,
            maximum: MAX_PATH_SIZE,
        });
    }
    let mask = (1u64 << CODE_SIZE) - 1;
    let mut explanation = Vec::with_capacity(size);
    for position in 0..size {
        let mut decoded = explain_rdkit_atom_code((code & mask) as u32);
        decoded.branch_count += if position == 0 || position + 1 == size {
            1
        } else {
            2
        };
        explanation.push(decoded);
        code >>= CODE_SIZE;
    }
    Ok(explanation)
}

// ---------------------------------------------------------------------------
// Torsion path enumeration + hashing
// ---------------------------------------------------------------------------

/// Every simple (no repeated atom) path of exactly 4 atoms in the molecular
/// graph, as `[a, b, c, d]` -- `findAllPathsOfLengthN(mol, 4, useBonds=false)`.
/// `findAllPathsOfLengthN` returns each undirected path once, not once per
/// direction (a path and its reverse walk are the same physical torsion) --
/// deduplicated here by keeping only the `a.0 < d.0` orientation of each
/// pair, matching that count exactly (confirmed empirically: without this,
/// every torsion's count-simulation bucket count was inflated 2x, setting
/// spurious extra threshold bits -- see this module's own investigation
/// notes / git history for the methyl-serinate repro that caught it).
///
/// Like RDKit (`useHs=false`), hydrogen atoms -- isotopic `[2H]`/`[3H]`
/// included -- are never part of a path.
fn four_atom_paths(mol: &Molecule) -> Vec<[AtomIdx; 4]> {
    let n = mol.atom_count();
    let heavy = |i: AtomIdx| !is_hydrogen(mol, i);
    let mut paths = Vec::new();
    for start in 0..n {
        let a = AtomIdx(start as u32);
        if !heavy(a) {
            continue;
        }
        for (b, _) in mol.neighbors(a).filter(|&(x, _)| heavy(x)) {
            for (c, _) in mol.neighbors(b).filter(|&(x, _)| heavy(x)) {
                if c == a {
                    continue;
                }
                for (d, _) in mol.neighbors(c).filter(|&(x, _)| heavy(x)) {
                    if d == a || d == b || d.0 <= a.0 {
                        continue;
                    }
                    paths.push([a, b, c, d]);
                }
            }
        }
    }
    paths
}

/// A 3-membered ring's own closure bond makes the ring itself walkable as a
/// 4-*position* torsion (`[a, b, c, a]`, revisiting `a`) using all 3 ring
/// bonds -- not found by [`four_atom_paths`] (which requires 4 *distinct*
/// atoms). Confirmed empirically against RDKit's own `SparseIntVect` output
/// (`rdFingerprintGenerator.GetTopologicalTorsionGenerator().GetCountFingerprint`):
/// a bare `C1CC1` (no substituent at all, only 3 heavy atoms -- no ordinary
/// 4-atom path can even exist) still yields exactly one nonzero torsion
/// entry, which can only come from this closed walk.
///
/// One entry per triangle, canonically starting from its lowest-`AtomIdx`
/// member (found once, when iterating that member as `a`, by requiring
/// `b.0 > a.0` and `c.0 > b.0`) -- [`torsion_hash`]'s own forward/reverse
/// canonicalization handles the rest. This matches RDKit's observed output
/// for a symmetric ring exactly; an *asymmetric* ring bearing different
/// substituents on two or more ring atoms can add further closed-walk
/// entries beyond this one (RDKit was observed emitting two for a
/// 1,2-disubstituted cyclopropane) -- the exact rule for those additional
/// entries is not yet reverse-engineered, so they are not generated here.
/// This is a known, narrower residual: still not full bit-exact parity for
/// molecules with an *asymmetrically substituted* 3-membered ring.
/// An atom RDKit's path search skips without `useHs` (atomic number 1).
fn is_hydrogen(mol: &Molecule, idx: AtomIdx) -> bool {
    let a = mol.atom(idx);
    !a.wildcard && a.element.atomic_number() == 1
}

fn triangle_closure_paths(mol: &Molecule) -> Vec<[AtomIdx; 4]> {
    let n = mol.atom_count();
    let mut paths = Vec::new();
    for start in 0..n {
        let a = AtomIdx(start as u32);
        for (b, _) in mol.neighbors(a) {
            if b.0 <= a.0 {
                continue;
            }
            for (c, _) in mol.neighbors(a) {
                if c.0 <= b.0 {
                    continue;
                }
                if mol.bond_between(b, c).is_some() {
                    paths.push([a, b, c, a]);
                }
            }
        }
    }
    paths
}

/// `getTopologicalTorsionHash`: builds each path position's code via
/// `invariant % (2^codeSize - 1) + 1`, then subtracts 1 more for the two
/// *interior* positions (index 1 and 2) -- the two *endpoint* positions
/// (index 0 and 3) keep the un-decremented value. Canonicalizes direction by
/// comparing the path's code sequence against its own reverse (mirroring
/// from both ends inward) and reading from whichever end yields the
/// lexicographically smaller sequence, then folds via [`hash_vec`] (the same
/// `gboost::hash_combine` sequential fold already verified for Morgan/ECFP4).
fn torsion_hash(atom_invariants: &[u32], path: &[AtomIdx; 4]) -> u32 {
    let modulus = (1u32 << CODE_SIZE) - 1;
    let mut path_codes: Vec<u32> = path
        .iter()
        .enumerate()
        .map(|(pos, &a)| {
            let mut code = atom_invariants[a.0 as usize] % modulus + 1;
            if pos != 0 && pos != path.len() - 1 {
                code -= 1;
            }
            code
        })
        .collect();

    let mut reverse_it = false;
    let (mut i, mut j) = (0usize, path_codes.len() - 1);
    while i < j {
        if path_codes[i] > path_codes[j] {
            reverse_it = true;
            break;
        } else if path_codes[i] < path_codes[j] {
            break;
        }
        i += 1;
        j -= 1;
    }
    if reverse_it {
        path_codes.reverse();
    }
    hash_vec(&path_codes)
}

/// RDKit-bit-exact Topological Torsion fingerprint, matching
/// `rdkit.Chem.AllChem.GetHashedTopologicalTorsionFingerprintAsBitVect(mol,
/// nBits=2048)` (`includeChirality=False`, `nBitsPerEntry=4`, the Python
/// API's own defaults) exactly. `torsionAtomCount` is fixed at 4 (RDKit's
/// own default); `includeChirality` is not supported (see [`atom_code`]).
///
/// Every torsion path (both [`four_atom_paths`]'s ordinary 4-distinct-atom
/// walks and [`triangle_closure_paths`]'s 3-membered-ring closures) folds
/// (via [`torsion_hash`]) into one of 512 buckets (`2048 / 4`); each
/// bucket's *count* of paths landing there is then expanded into 4
/// threshold bits (`count >= 1, 2, 4, 8`) -- RDKit's "count simulation"
/// scheme, not a plain one-bit-per-feature encoding. This is why chematic's
/// own native [`crate::atom_pair::torsion_fp`] (a different, non-RDKit
/// scheme) and this function produce structurally different bit patterns
/// even before considering the atom-code/hashing differences.
///
/// Known residual (not yet bit-exact): an *asymmetrically substituted*
/// 3-membered ring can require more than one closure entry per ring (see
/// [`triangle_closure_paths`]'s doc comment) -- measured at ~87% bit-exact
/// on a 200-molecule general corpus sample, with essentially all remaining
/// misses confined to this one narrow structural class.
pub fn rdkit_torsion_fp(mol: &Molecule) -> BitVec2048 {
    chematic_smiles::with_rdkit_model_molecule(mol, rdkit_torsion_fp_impl)
}

fn rdkit_torsion_fp_impl(mol: &Molecule) -> BitVec2048 {
    // RDKit fingerprints sanitized molecules, i.e. after aromaticity
    // perception; Kekule input must not see a different graph than the
    // equivalent aromatic spelling. The perceived view is memoized on `mol`.
    chematic_perception::with_rdkit_parity_view(mol, |view| {
        rdkit_torsion_fp_prepared(view.unwrap_or(mol))
    })
}

/// Per-bucket torsion counts (`getHashedTopologicalTorsionFingerprint`).
fn torsion_bucket_counts(mol: &Molecule, atom_invariants: &[u32], n_buckets: u32) -> Vec<u32> {
    let mut counts = vec![0u32; n_buckets as usize];
    for path in four_atom_paths(mol)
        .into_iter()
        .chain(triangle_closure_paths(mol))
    {
        let h = torsion_hash(atom_invariants, &path);
        let bucket = (h % n_buckets) as usize;
        counts[bucket] = counts[bucket].saturating_add(1);
    }
    counts
}

/// RDKit's hashed topological-torsion *count* fingerprint
/// (`rdMolDescriptors.GetHashedTopologicalTorsionFingerprint(mol, nBits)`):
/// the nonzero `(bucket, count)` elements, sorted by bucket.
pub fn rdkit_torsion_counts(mol: &Molecule, n_bits: u32) -> Vec<(u32, u32)> {
    chematic_smiles::with_rdkit_model_molecule(mol, |m| rdkit_torsion_counts_impl(m, n_bits))
}

fn rdkit_torsion_counts_impl(mol: &Molecule, n_bits: u32) -> Vec<(u32, u32)> {
    let n_bits = n_bits.max(1);
    chematic_perception::with_rdkit_parity_view(mol, |view| {
        let m = view.unwrap_or(mol);
        let invariants: Vec<u32> = (0..m.atom_count())
            .map(|i| atom_code(m, AtomIdx(i as u32), 0).wrapping_sub(2))
            .collect();
        torsion_bucket_counts(m, &invariants, n_bits)
            .into_iter()
            .enumerate()
            .filter(|&(_, c)| c > 0)
            .map(|(b, c)| (b as u32, c))
            .collect()
    })
}

/// `getTopologicalTorsionCode(pathCodes, includeChirality=false)`: the
/// path codes (read from the end with the smaller code first) packed
/// `CODE_SIZE` bits apart, as an unsigned 64-bit value.
fn torsion_code(path_codes: &[u32; 4]) -> u64 {
    let mut reverse_it = false;
    let (mut i, mut j) = (0usize, 3usize);
    while i < j {
        if path_codes[i] > path_codes[j] {
            reverse_it = true;
            break;
        } else if path_codes[i] < path_codes[j] {
            break;
        }
        i += 1;
        j -= 1;
    }
    let mut res = 0u64;
    for k in 0..4 {
        let c = if reverse_it {
            path_codes[3 - k]
        } else {
            path_codes[k]
        };
        res |= u64::from(c) << (CODE_SIZE as usize * k);
    }
    res
}

/// Nonzero `(code, count)` elements of the unhashed torsion codes, sorted.
fn torsion_code_counts(mol: &Molecule, code_of: impl Fn(AtomIdx, bool) -> u32) -> Vec<(u64, u32)> {
    let mut counts: std::collections::BTreeMap<u64, u32> = std::collections::BTreeMap::new();
    for path in four_atom_paths(mol)
        .into_iter()
        .chain(triangle_closure_paths(mol))
    {
        let mut codes = [0u32; 4];
        for (pos, &a) in path.iter().enumerate() {
            codes[pos] = code_of(a, pos != 0 && pos != 3);
        }
        *counts.entry(torsion_code(&codes)).or_insert(0) += 1;
    }
    counts.into_iter().collect()
}

/// RDKit's unhashed topological-torsion count fingerprint
/// (`rdFingerprintGenerator.GetTopologicalTorsionGenerator()
/// .GetSparseCountFingerprint(mol)`, torsion atom count 4, no chirality):
/// the nonzero `(code, count)` elements, sorted by code.
pub fn rdkit_torsion_sparse_counts(mol: &Molecule) -> Vec<(u64, u32)> {
    chematic_perception::with_rdkit_parity_view(mol, |view| {
        let m = view.unwrap_or(mol);
        let modulus = (1u32 << CODE_SIZE) - 1;
        torsion_code_counts(m, |a, interior| {
            let inv = atom_code(m, a, 0).wrapping_sub(2);
            inv % modulus + 1 - u32::from(interior)
        })
    })
}

/// RDKit's legacy `rdMolDescriptors.GetTopologicalTorsionFingerprint(mol)`
/// (`AtomPairs::getTopologicalTorsionFingerprint`, targetSize 4, no
/// chirality): atom codes `getAtomCode - 1` (one less on the interior
/// atoms, unsigned arithmetic as in C++), packed by
/// `getTopologicalTorsionCode`; the nonzero `(code, count)` elements of
/// the `SparseIntVect<int64_t>`, sorted by code.
pub fn rdkit_legacy_torsion_counts(mol: &Molecule) -> Vec<(i64, u32)> {
    // RDKit fingerprints its hydrogen-suppressed molecule (`[H]` atoms gone).
    if let Some(h) = chematic_smiles::rdkit_hydrogen_suppressed(mol) {
        return rdkit_legacy_torsion_counts(&h);
    }
    chematic_perception::with_rdkit_parity_view(mol, |view| {
        let m = view.unwrap_or(mol);
        let mut v: Vec<(i64, u32)> = torsion_code_counts(m, |a, interior| {
            atom_code(m, a, 0)
                .wrapping_sub(1)
                .wrapping_sub(u32::from(interior))
        })
        .into_iter()
        .map(|(c, n)| (c as i64, n))
        .collect();
        v.sort_unstable();
        v
    })
}

/// [`rdkit_torsion_fp`] on a molecule whose aromaticity is already RDKit-perceived.
fn rdkit_torsion_fp_prepared(mol: &Molecule) -> BitVec2048 {
    let n = mol.atom_count();
    // `AtomPairAtomInvGenerator::getAtomInvariants()`'s
    // `topologicalTorsionCorrection`: every atom invariant used for torsion
    // hashing is `getAtomCode(atom, 0, includeChirality) - 2` -- a raw
    // `uint32_t` subtraction (wraps on underflow when the code is 0 or 1,
    // matching C++'s well-defined unsigned modular arithmetic; `%
    // (2^codeSize-1) + 1` in `torsion_hash` washes the wraparound back into
    // range, but the wraparound itself must happen first to get the same
    // washed-out value RDKit does).
    let atom_invariants: Vec<u32> = (0..n)
        .map(|i| atom_code(mol, AtomIdx(i as u32), 0).wrapping_sub(2))
        .collect();

    const BLOCK_LENGTH: u32 = 2048 / N_BITS_PER_ENTRY as u32;
    let counts = torsion_bucket_counts(mol, &atom_invariants, BLOCK_LENGTH);

    let mut fp = BitVec2048::new();
    for (bucket, &count) in counts.iter().enumerate() {
        for (i, &bound) in COUNT_BOUNDS.iter().enumerate() {
            if count >= bound {
                fp.set(bucket * N_BITS_PER_ENTRY + i);
            }
        }
    }
    fp
}

#[cfg(test)]
mod tests {
    use super::*;
    use chematic_smiles::parse;

    fn mol(s: &str) -> Molecule {
        parse(s).unwrap_or_else(|e| panic!("parse '{s}': {e}"))
    }

    #[test]
    fn atom_type_index_exact_match() {
        assert_eq!(atom_type_index(6), 1); // carbon, 2nd entry
        assert_eq!(atom_type_index(5), 0); // boron, 1st entry
        assert_eq!(atom_type_index(53), 14); // iodine, last entry
    }

    #[test]
    fn atom_type_index_below_table_clamps_to_phantom_slot() {
        // H (1) is smaller than every table entry -> clamps to the phantom
        // 16th slot (index 15), matching the C++ array's implicit
        // zero-initialized 16th element and nTypes=1<<numTypeBits=16 bound.
        assert_eq!(atom_type_index(1), 15);
    }

    #[test]
    fn atom_type_index_between_entries_clamps_to_phantom_slot_too() {
        // 10 (Ne) falls between 9 and 14 in the table -- NOT "nearest below":
        // any non-exact match clamps to the same phantom slot 15, verified
        // by tracing the C++ loop by hand (the "greater" branch jumps
        // straight to nTypes regardless of how far into the table it got).
        assert_eq!(atom_type_index(10), 15);
    }

    #[test]
    fn atom_type_index_above_table_clamps_to_phantom_slot() {
        assert_eq!(atom_type_index(79), 15); // Au
    }

    #[test]
    fn public_atom_code_explanation_matches_reference_fields() {
        let m = mol("C=CC(=O)O");
        let expected = [
            ("C", 1, 1),
            ("C", 2, 1),
            ("C", 3, 1),
            ("O", 1, 1),
            ("O", 1, 0),
        ];
        for (atom, &(symbol, branches, pi)) in expected.iter().enumerate() {
            let code = rdkit_atom_code(&m, AtomIdx(atom as u32), 0).unwrap();
            assert_eq!(
                explain_rdkit_atom_code(code),
                RdkitAtomCodeExplanation {
                    symbol,
                    branch_count: branches,
                    pi_electron_count: pi,
                }
            );
        }
    }

    #[test]
    fn public_path_code_is_direction_independent_and_explainable() {
        let m = mol("OOOO");
        let forward = [AtomIdx(0), AtomIdx(1), AtomIdx(2), AtomIdx(3)];
        let reverse = [AtomIdx(3), AtomIdx(2), AtomIdx(1), AtomIdx(0)];
        let code = rdkit_topological_torsion_path_code(&m, &forward).unwrap();
        assert_eq!(
            code,
            rdkit_topological_torsion_path_code(&m, &reverse).unwrap()
        );
        assert_eq!(
            explain_rdkit_topological_torsion_code(code, 4).unwrap(),
            vec![
                RdkitAtomCodeExplanation {
                    symbol: "O",
                    branch_count: 1,
                    pi_electron_count: 0,
                },
                RdkitAtomCodeExplanation {
                    symbol: "O",
                    branch_count: 2,
                    pi_electron_count: 0,
                },
                RdkitAtomCodeExplanation {
                    symbol: "O",
                    branch_count: 2,
                    pi_electron_count: 0,
                },
                RdkitAtomCodeExplanation {
                    symbol: "O",
                    branch_count: 1,
                    pi_electron_count: 0,
                },
            ]
        );
    }

    #[test]
    fn public_diagnostics_reject_invalid_indices_and_sizes() {
        let m = mol("CC");
        assert!(matches!(
            rdkit_atom_code(&m, AtomIdx(2), 0),
            Err(RdkitTorsionDiagnosticError::AtomIndexOutOfRange { .. })
        ));
        assert_eq!(
            rdkit_topological_torsion_path_code(&m, &[]),
            Err(RdkitTorsionDiagnosticError::EmptyPath)
        );
        assert!(matches!(
            explain_rdkit_topological_torsion_code(0, 8),
            Err(RdkitTorsionDiagnosticError::PathTooLong { maximum: 7, .. })
        ));
    }

    #[test]
    fn num_pi_electrons_aromatic_atom_is_always_one() {
        let m = mol("c1ccccc1");
        assert_eq!(num_pi_electrons(&m, AtomIdx(0)), 1);
    }

    #[test]
    fn num_pi_electrons_single_bonds_only_is_zero() {
        let m = mol("CCO");
        assert_eq!(num_pi_electrons(&m, AtomIdx(0)), 0);
    }

    #[test]
    fn num_pi_electrons_double_bond_is_one() {
        let m = mol("C=O");
        assert_eq!(num_pi_electrons(&m, AtomIdx(0)), 1);
        assert_eq!(num_pi_electrons(&m, AtomIdx(1)), 1);
    }

    #[test]
    fn num_pi_electrons_triple_bond_is_two() {
        let m = mol("C#N");
        assert_eq!(num_pi_electrons(&m, AtomIdx(0)), 2);
        assert_eq!(num_pi_electrons(&m, AtomIdx(1)), 2);
    }

    #[test]
    fn four_atom_paths_linear_butane_finds_one_undirected_path() {
        let m = mol("CCCC");
        let paths = four_atom_paths(&m);
        assert_eq!(
            paths.len(),
            1,
            "one physical path, one direction kept: {paths:?}"
        );
    }

    #[test]
    fn four_atom_paths_none_shorter_than_four_atoms() {
        let m = mol("CCC");
        assert!(four_atom_paths(&m).is_empty());
    }

    #[test]
    fn triangle_closure_finds_one_entry_for_bare_cyclopropane() {
        let m = mol("C1CC1");
        // No ordinary 4-distinct-atom path can exist (only 3 heavy atoms
        // total) -- the ring's own closure bond is the only source of any
        // torsion contribution at all.
        assert!(four_atom_paths(&m).is_empty());
        let closures = triangle_closure_paths(&m);
        assert_eq!(closures.len(), 1, "{closures:?}");
        assert_eq!(closures[0][0], closures[0][3], "pivot atom must repeat");
    }

    #[test]
    fn triangle_closure_pivot_is_lowest_index_ring_atom() {
        let m = mol("CC1CC1"); // methyl on atom 1 -- ring is {1, 2, 3}
        let closures = triangle_closure_paths(&m);
        assert_eq!(closures.len(), 1, "{closures:?}");
        assert_eq!(closures[0][0], AtomIdx(1));
        assert_eq!(closures[0][3], AtomIdx(1));
    }

    #[test]
    fn triangle_closure_empty_for_larger_rings() {
        let m = mol("C1CCC1"); // 4-membered ring, no triangle
        assert!(triangle_closure_paths(&m).is_empty());
    }

    #[test]
    fn triangle_closure_empty_for_non_cyclic_molecules() {
        let m = mol("CCCC");
        assert!(triangle_closure_paths(&m).is_empty());
    }

    #[test]
    fn rdkit_torsion_fp_nonempty_for_bare_cyclopropane() {
        // Before triangle_closure_paths existed, this molecule had zero
        // possible torsion contributions under the old (4-distinct-atom-only)
        // enumeration -- RDKit's own real output is nonempty (one entry),
        // so an empty fingerprint here would itself be a parity bug.
        let m = mol("C1CC1");
        assert!(rdkit_torsion_fp(&m).popcount() > 0);
    }

    #[test]
    fn rdkit_torsion_fp_deterministic_and_nonempty_for_butane() {
        let m = mol("CCCC");
        let fp1 = rdkit_torsion_fp(&m);
        let fp2 = rdkit_torsion_fp(&m);
        assert_eq!(fp1.popcount(), fp2.popcount());
        assert!(fp1.popcount() > 0);
    }

    #[test]
    fn rdkit_torsion_fp_empty_for_short_molecules() {
        let m = mol("CCC"); // only 3 heavy atoms, no 4-atom path exists
        let fp = rdkit_torsion_fp(&m);
        assert_eq!(fp.popcount(), 0);
    }
}
