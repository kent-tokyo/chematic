//! Atom type: a single atom in a molecule.

use crate::element::Element;

/// A `@SP1`/`@SP2`/`@SP3` square-planar stereo tag (OpenSMILES's extended
/// chirality-class syntax, e.g. Pt(II)/Pd(II) complexes like cisplatin).
///
/// Each variant names which pair of the 4 explicit neighbor positions
/// (0-indexed, in the order recorded by [`crate::Molecule::stereo_neighbor_order`])
/// sit *trans* (~180°) to each other:
///
/// - `SP1`: positions (0,2) trans, (1,3) trans
/// - `SP2`: positions (0,1) trans, (2,3) trans
/// - `SP3`: positions (0,3) trans, (1,2) trans
///
/// Oracle-verified against RDKit 2026.03.3 (3D embedding bond angles, cross-checked
/// against RDKit's own documented cisplatin/transplatin example) — see
/// `docs/rfcs/square_planar_stereo_rfc.md`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum SquarePlanarPermutation {
    SP1,
    SP2,
    SP3,
}

impl SquarePlanarPermutation {
    /// The two trans-pairs this permutation implies, as 0-indexed neighbor positions.
    pub fn trans_pairs(self) -> [(u8, u8); 2] {
        match self {
            Self::SP1 => [(0, 2), (1, 3)],
            Self::SP2 => [(0, 1), (2, 3)],
            Self::SP3 => [(0, 3), (1, 2)],
        }
    }
}

/// Chirality as specified in OpenSMILES: tetrahedral (`@`/`@@`) or, since this
/// crate also models coordination complexes, square-planar
/// (`@SP1`/`@SP2`/`@SP3`). Allene `@AL1`/`@AL2` parity uses the same two
/// parity values and is distinguished by the molecule's six-entry virtual
/// terminal order; see [`crate::Molecule::is_allene_stereo`].
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum Chirality {
    /// No chirality specified.
    #[default]
    None,
    /// `@` — counterclockwise (looking from the first neighbor).
    CounterClockwise,
    /// `@@` — clockwise.
    Clockwise,
    /// `@SP1`/`@SP2`/`@SP3` — square-planar (4-coordinate) stereo.
    SquarePlanar(SquarePlanarPermutation),
    /// `@SP` without a permutation number (RDKit keeps the class, permutation 0).
    SquarePlanarUnnumbered,
    /// `@TB1`..`@TB20` — trigonal-bipyramidal (5-coordinate) stereo; 0 is
    /// `@TB` without a permutation number.
    TrigonalBipyramidal(u8),
    /// `@OH1`..`@OH30` — octahedral (6-coordinate) stereo; 0 is `@OH`
    /// without a permutation number.
    Octahedral(u8),
}

impl Chirality {
    /// Source-compatible spelling for the first allene/cumulene axial
    /// permutation. Allene geometry is molecular context, not a third atom
    /// parity state, so this aliases [`Self::CounterClockwise`].
    #[allow(non_upper_case_globals)]
    pub const Allene1: Self = Self::CounterClockwise;

    /// Source-compatible spelling for the second allene/cumulene axial
    /// permutation. Allene geometry is molecular context, not a fourth atom
    /// parity state, so this aliases [`Self::Clockwise`].
    #[allow(non_upper_case_globals)]
    pub const Allene2: Self = Self::Clockwise;

    /// `true` only for [`Self::CounterClockwise`]/[`Self::Clockwise`] — the classic
    /// tetrahedral-parity forms every CIP/ECFP/dedup consumer written before
    /// square-planar existed assumes. Consumers that mean "is this a real
    /// tetrahedral stereocenter" must check this, not `!= Self::None`, now that a
    /// second non-tetrahedral kind of "not None" chirality exists.
    pub fn is_tetrahedral(&self) -> bool {
        matches!(self, Self::CounterClockwise | Self::Clockwise)
    }

    /// Allene class cannot be determined from atom parity alone. Use
    /// [`crate::Molecule::is_allene_stereo`] with the owning molecule.
    #[deprecated(
        since = "1.1.4",
        note = "allene class is molecular context; use Molecule::is_allene_stereo"
    )]
    pub fn is_allene(&self) -> bool {
        false
    }

    /// The non-tetrahedral class and permutation number (0: none given),
    /// `None` for tetrahedral or absent stereo.
    pub fn nontetrahedral(&self) -> Option<(crate::NonTetrahedralClass, u32)> {
        use crate::NonTetrahedralClass as C;
        match *self {
            Self::SquarePlanar(p) => Some((
                C::SquarePlanar,
                match p {
                    SquarePlanarPermutation::SP1 => 1,
                    SquarePlanarPermutation::SP2 => 2,
                    SquarePlanarPermutation::SP3 => 3,
                },
            )),
            Self::SquarePlanarUnnumbered => Some((C::SquarePlanar, 0)),
            Self::TrigonalBipyramidal(p) => Some((C::TrigonalBipyramidal, u32::from(p))),
            Self::Octahedral(p) => Some((C::Octahedral, u32::from(p))),
            _ => None,
        }
    }

    /// The chirality for a non-tetrahedral class and permutation number
    /// (0: none given); `None` past the class's largest permutation.
    pub fn from_nontetrahedral(class: crate::NonTetrahedralClass, perm: u32) -> Option<Self> {
        use crate::NonTetrahedralClass as C;
        if perm > class.max_permutation() {
            return None;
        }
        Some(match (class, perm) {
            (C::SquarePlanar, 0) => Self::SquarePlanarUnnumbered,
            (C::SquarePlanar, 1) => Self::SquarePlanar(SquarePlanarPermutation::SP1),
            (C::SquarePlanar, 2) => Self::SquarePlanar(SquarePlanarPermutation::SP2),
            (C::SquarePlanar, _) => Self::SquarePlanar(SquarePlanarPermutation::SP3),
            (C::TrigonalBipyramidal, p) => Self::TrigonalBipyramidal(p as u8),
            (C::Octahedral, p) => Self::Octahedral(p as u8),
        })
    }

    /// The SMILES chirality token (`@`, `@@`, `@SP2`, `@TB7`, `@OH`, ...),
    /// empty for no stereo.
    pub fn smiles_token(&self) -> String {
        match self {
            Self::None => String::new(),
            Self::CounterClockwise => "@".into(),
            Self::Clockwise => "@@".into(),
            _ => {
                let (class, perm) = self.nontetrahedral().expect("non-tetrahedral");
                if perm == 0 {
                    format!("@{}", class.token())
                } else {
                    format!("@{}{perm}", class.token())
                }
            }
        }
    }
}

/// Assigned CIP (Cahn–Ingold–Prelog) stereodescriptor.
///
/// Stored on [`Atom`] after running [`chematic_chem::assign_cip`] or
/// [`chematic_chem::cip::assign_cip`].
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum CipCode {
    /// Tetrahedral center with *rectus* (right-handed) configuration.
    R,
    /// Tetrahedral center with *sinister* (left-handed) configuration.
    S,
    /// Double-bond *entgegen* (opposite, trans) geometry.
    E,
    /// Double-bond *zusammen* (together, cis) geometry.
    Z,
    /// Pseudoasymmetric center, *rectus*-like (Rule 5, lowercase `r`). Emitted only by
    /// `chematic_cip::assign_cip_accurate_experimental`'s Rule 5 pass; the default
    /// `chematic_chem::assign_cip` never produces this variant.
    LowerR,
    /// Pseudoasymmetric center, *sinister*-like (Rule 5, lowercase `s`). See [`Self::LowerR`].
    LowerS,
}

/// Display/interchange label for an atom-level R-group placeholder.
///
/// An R-group is still a wildcard for chemistry algorithms; this value only
/// preserves whether the source document spelled that wildcard as `R` or as a
/// numbered label such as `R1`. The number is in `1..=9999`, the range that
/// can be emitted losslessly by both V2000's fixed-width `M  RGP` record and
/// the less constrained supported formats.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct RGroupLabel(Option<core::num::NonZeroU16>);

impl RGroupLabel {
    /// An unnumbered `R` placeholder.
    pub const fn unnumbered() -> Self {
        Self(None)
    }

    /// A numbered `R<n>` placeholder. Returns `None` outside `1..=9999`.
    pub fn numbered(number: u16) -> Option<Self> {
        core::num::NonZeroU16::new(number)
            .filter(|number| number.get() <= 9999)
            .map(|number| Self(Some(number)))
    }

    /// The positive R-group number, or `None` for an unnumbered `R`.
    pub const fn number(self) -> Option<u16> {
        match self.0 {
            Some(number) => Some(number.get()),
            None => None,
        }
    }
}

/// A single atom in a molecular graph.
///
/// Caller labels belong to [`crate::Molecule::atom_tag`], keeping this public
/// chemical value and its equality independent of tracking metadata.
///
/// - `isotope`: mass number (e.g. 13 for ¹³C). `None` = natural isotope abundance.
/// - `charge`: formal charge.
/// - `hydrogen_count`: explicit H count from a bracket atom `[...]`.
///   `None` for organic-subset atoms whose H count is inferred from valence.
/// - `aromatic`: set when the atom is written as a lowercase letter (c, n, …)
///   or connected via `:` bonds.
/// - `wildcard`: `true` for the SMILES `*` atom (any element, query context).
/// - `atom_map`: atom-mapping number used in reaction SMILES.
/// - `cip_code`: CIP stereodescriptor (R/S/E/Z). Populated by
///   `chematic_chem::assign_cip`; `None` until then.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Atom {
    pub element: Element,
    pub isotope: Option<u16>,
    pub charge: i8,
    /// Explicit H count (bracket atoms only). `None` for organic-subset atoms.
    pub hydrogen_count: Option<u8>,
    pub aromatic: bool,
    pub chirality: Chirality,
    /// True for the wildcard atom `*` or `[*]`.
    pub wildcard: bool,
    pub atom_map: Option<u16>,
    /// CIP stereodescriptor assigned by `chematic_chem::assign_cip`.
    /// `None` until explicitly computed.
    pub cip_code: Option<CipCode>,
}

impl Atom {
    /// Create a plain, neutral, non-aromatic atom.
    pub fn new(element: Element) -> Self {
        Self {
            element,
            isotope: None,
            charge: 0,
            hydrogen_count: None,
            aromatic: false,
            chirality: Chirality::None,
            wildcard: false,
            atom_map: None,
            cip_code: None,
        }
    }

    /// Organic-subset atom (charge=0, non-aromatic, implicit H from valence).
    pub fn organic(element: Element) -> Self {
        Self::new(element)
    }

    /// Aromatic organic atom (lowercase SMILES notation).
    pub fn aromatic(element: Element) -> Self {
        Self {
            aromatic: true,
            ..Self::new(element)
        }
    }

    /// Bracket atom with explicit properties.
    pub fn bracket(
        element: Element,
        isotope: Option<u16>,
        chirality: Chirality,
        hydrogen_count: u8,
        charge: i8,
        atom_map: Option<u16>,
    ) -> Self {
        Self {
            element,
            isotope,
            charge,
            hydrogen_count: Some(hydrogen_count),
            aromatic: false,
            chirality,
            wildcard: false,
            atom_map,
            cip_code: None,
        }
    }

    /// Wildcard atom `*` / `[*]` (matches any element in query contexts).
    pub fn wildcard() -> Self {
        Self {
            // Element is a placeholder; callers should check `wildcard` first.
            element: Element::C,
            wildcard: true,
            hydrogen_count: Some(0),
            ..Self::new(Element::C)
        }
    }

    /// Return the explicit H count for bracket atoms; `None` for organic-subset atoms.
    pub fn explicit_hcount(&self) -> Option<u8> {
        self.hydrogen_count
    }
}

impl core::fmt::Display for Atom {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        if self.wildcard {
            return write!(f, "*");
        }
        let symbol = if self.aromatic {
            self.element.symbol().to_lowercase()
        } else {
            self.element.symbol().to_string()
        };
        match self.isotope {
            Some(iso) => write!(f, "[{iso}{symbol}]"),
            None => write!(f, "{symbol}"),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_atom_new() {
        let a = Atom::new(Element::C);
        assert_eq!(a.element, Element::C);
        assert_eq!(a.charge, 0);
        assert!(!a.aromatic);
        assert!(!a.wildcard);
        assert_eq!(a.hydrogen_count, None);
    }

    #[test]
    fn test_aromatic_atom() {
        let a = Atom::aromatic(Element::C);
        assert!(a.aromatic);
    }

    #[test]
    fn test_wildcard_atom() {
        let a = Atom::wildcard();
        assert!(a.wildcard);
        assert_eq!(format!("{a}"), "*");
    }

    #[test]
    fn r_group_label_rejects_zero() {
        assert!(RGroupLabel::numbered(0).is_none());
        assert!(RGroupLabel::numbered(10_000).is_none());
        assert_eq!(RGroupLabel::numbered(2).unwrap().number(), Some(2));
        assert_eq!(RGroupLabel::unnumbered().number(), None);
    }
}
