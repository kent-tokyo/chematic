//! Per-molecule memoization of derived perception data.
//!
//! Many descriptors, fingerprints and SMARTS matches need the same derived
//! views of a molecule (the SSSR, an aromaticity-perceived copy, …). Without
//! memoization each public call recomputed them from scratch, which made
//! repeated calls on the same [`Molecule`](crate::Molecule) pay the full
//! perception cost every time.
//!
//! The cache is invisible to callers:
//!
//! * it is cleared by every `&mut self` method on `Molecule`, so a mutated
//!   graph can never observe stale derived data;
//! * cloning a `Molecule` yields an *empty* cache, so code that clones and
//!   then edits (including crate-internal `with_*` helpers) stays correct;
//! * values are computed outside the cell and published with `set`, so a
//!   computation may itself consult other slots of the same molecule.

use std::any::Any;
use std::panic::{RefUnwindSafe, UnwindSafe};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, OnceLock};

/// Well-known derived-data slots. Each slot stores exactly one Rust type,
/// chosen by the perception crate that owns it.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[non_exhaustive]
#[doc(hidden)]
pub enum DerivedSlot {
    /// `chematic_perception::RingSet` from `find_sssr`.
    Sssr = 0,
    /// Cyclic-bond flags from `ring_bond_flags`.
    RingBondFlags = 1,
    /// Aromaticity-perceived copy used by descriptor calculations.
    DescriptorAromatic = 2,
    /// Wildman–Crippen atom-type index per atom (on the descriptor aromatic view).
    CrippenTypes = 3,
    /// Winning canonical ranks and canonical SMILES string.
    CanonicalRanks = 4,
    /// Result of the RDKit-parity aromaticity perception.
    RdkitParityAromatic = 5,
    /// Which shortcut (if any) the RDKit-parity perception can take.
    RdkitParityShortcut = 6,
    /// Cyclic-subgraph component labels (computed with `RingBondFlags`).
    RingComponents = 7,
    /// Kekulé orders of the aromatic bonds (`None` when kekulization fails),
    /// used for total-valence queries.
    KekuleOrders = 8,
    /// Topological atom-equivalence classes (canonical SMILES writer).
    TopologicalClasses = 9,
    /// The reactant RDKit's SMILES parser would see (stereo tags it drops
    /// removed); `chematic-rxn`'s RDKit reaction profile.
    RdkitParseCleanup = 10,
    /// Whether RDKit's ring models (symmetrized rings for `R<n>` and ring
    /// sizes) equal the SSSR for this molecule; `chematic-rxn`.
    RdkitRingModelIsSssr = 11,
    /// RDKit hybridization code per atom (the SMARTS `^n` primitive);
    /// `chematic-smarts`.
    RdkitHybridization = 12,
    /// The single bonds RDKit's `cleanUpOrganometallics` makes dative, as
    /// decided on the molecule as input (`chematic-perception`). An
    /// RDKit-parity view is seeded with "none": its dative bonds are
    /// already written as such.
    RdkitDativeBonds = 13,
    /// Per-target ring models and lookup tables of the RDKit-parity SMARTS
    /// matcher (`chematic-smarts`), shared by every query run on a target.
    RdkitParityMatch = 14,
    /// RDKit's `numPiElectrons` per atom on its sanitized model, where
    /// chematic's perception may disagree with RDKit's; `chematic-fp`.
    RdkitPiElectrons = 15,
    /// Whether chematic's perception may disagree with RDKit's model of the
    /// molecule (`chematic_perception::rdkit_model_may_disagree`).
    RdkitModelGate = 16,
    /// Prepared RDKit Morgan atom/bond stereochemistry; `chematic-fp`.
    RdkitMorganStereo = 17,
}

const SLOT_COUNT: usize = 18;

/// Scalar descriptor slots owned by `chematic-chem`. Keeping their f64
/// values inline avoids allocation, reference counting and type erasure
/// on hot property reads. All bit patterns, including NaNs, are valid.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[non_exhaustive]
#[doc(hidden)]
pub enum DerivedScalar {
    Tpsa = 0,
    RdkitTpsa = 1,
    LabuteAsa = 2,
}

/// Stored values keep `Molecule`'s auto traits: `Send + Sync` for Rayon and
/// the unwind-safety traits so `Molecule` stays usable across
/// `std::panic::catch_unwind` (as it was before the cache existed).
type Erased = dyn Any + Send + Sync + RefUnwindSafe + UnwindSafe;

type Slot = OnceLock<Arc<Erased>>;

pub(crate) struct DerivedCache {
    slots: [Slot; SLOT_COUNT],
    scalars: [OnceLock<f64>; 3],
    /// Kept outside the type-erased slots because this descriptor is a very
    /// hot scalar property.  Avoiding `Arc<dyn Any>` and a downcast makes a
    /// prepared ring-count lookup comparable to RDKit's native cache read.
    rdkit_num_rings: AtomicUsize,
}

impl Default for DerivedCache {
    fn default() -> Self {
        Self {
            slots: [const { OnceLock::new() }; SLOT_COUNT],
            scalars: [const { OnceLock::new() }; 3],
            rdkit_num_rings: AtomicUsize::new(usize::MAX),
        }
    }
}

impl Clone for DerivedCache {
    /// Clones start empty; see the module documentation.
    fn clone(&self) -> Self {
        Self::default()
    }
}

impl DerivedCache {
    #[inline(always)]
    pub(crate) fn scalar(&self, slot: DerivedScalar, compute: impl FnOnce() -> f64) -> f64 {
        let cell = &self.scalars[slot as usize];
        if let Some(value) = cell.get() {
            *value
        } else {
            // Compute outside OnceLock's initialization lock, as for the
            // other derived slots. Concurrent cold readers may compute the
            // same deterministic value; no recursive initializer can deadlock.
            let value = compute();
            let _ = cell.set(value);
            value
        }
    }

    #[inline(always)]
    pub(crate) fn rdkit_num_rings(&self, compute: impl FnOnce() -> usize) -> usize {
        let count = self.rdkit_num_rings.load(Ordering::Relaxed);
        if count != usize::MAX {
            count
        } else {
            // Concurrent readers may compute the same deterministic scalar
            // more than once.  Publishing with relaxed ordering is enough:
            // the value carries no pointer/data dependency and mutation
            // replaces the complete `DerivedCache` under `&mut self`.
            let count = compute();
            debug_assert_ne!(count, usize::MAX);
            self.rdkit_num_rings.store(count, Ordering::Relaxed);
            count
        }
    }

    pub(crate) fn get_or_compute<T, F>(&self, slot: DerivedSlot, compute: F) -> Arc<T>
    where
        T: Any + Send + Sync + RefUnwindSafe + UnwindSafe,
        F: FnOnce() -> T,
    {
        let cell = &self.slots[slot as usize];
        if let Some(existing) = cell.get() {
            let any: Arc<dyn Any + Send + Sync> = Arc::<Erased>::clone(existing);
            if let Ok(value) = any.downcast::<T>() {
                return value;
            }
            // A slot is owned by exactly one type; a mismatch is a
            // programming error, but never return wrong data — just recompute.
            debug_assert!(false, "derived-cache slot {slot:?} type mismatch");
            return Arc::new(compute());
        }
        let value = Arc::new(compute());
        let erased: Arc<Erased> = value.clone();
        // A concurrent writer may have won; either value is identical.
        let _ = cell.set(erased);
        value
    }

    /// Publish `value` for `slot` unless the slot is already filled.
    pub(crate) fn seed<T>(&self, slot: DerivedSlot, value: Arc<T>)
    where
        T: Any + Send + Sync + RefUnwindSafe + UnwindSafe,
    {
        let erased: Arc<Erased> = value;
        let _ = self.slots[slot as usize].set(erased);
    }

    /// The value already memoized for `slot`, if any (never computes).
    pub(crate) fn peek<T>(&self, slot: DerivedSlot) -> Option<Arc<T>>
    where
        T: Any + Send + Sync + RefUnwindSafe + UnwindSafe,
    {
        let existing = self.slots[slot as usize].get()?;
        let any: Arc<dyn Any + Send + Sync> = Arc::<Erased>::clone(existing);
        any.downcast::<T>().ok()
    }
}
