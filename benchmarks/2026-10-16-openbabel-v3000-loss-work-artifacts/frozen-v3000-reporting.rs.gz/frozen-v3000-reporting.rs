pub fn write_mol_v3000_with_stereo_report(
    mol: &Molecule,
    metadata: &MolMetadata,
    coords: &[(f64, f64)],
) -> (String, crate::MolStereoLoss) {
    let mut out = writer_buffer(mol, metadata);
    append_header(&mut out, mol, metadata, "  chematic\n");

    let depiction = crate::stereo_depiction::needs_stereo_depiction(mol)
        .then(|| crate::stereo_depiction::stereo_depiction(mol, coords));
    let coords = depiction.as_ref().map_or(coords, |value| &value.coords);

    append_atoms_2d(&mut out, mol, metadata, coords);
    append_bonds_2d(&mut out, mol, metadata, depiction.as_ref());
    finish_ctab(&mut out, mol, metadata);

    let loss = crate::MolStereoLoss::from_depiction(
        mol,
        depiction.as_ref(),
        crate::mol2000::MolFormat::V3000,
    );
    (out, loss)
}
